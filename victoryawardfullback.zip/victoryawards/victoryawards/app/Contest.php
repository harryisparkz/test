<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Contest extends Model
{
     protected $table = 'wn_contests';
	// protect from mass assignment vulnerabilities
	  protected $fillable = [
	'name',
	'description',
	'category',
	'start_date',
	'end_date',
	'voting_start_date',
	'voting_end_date',
	'payment_type',
	'image',
	'status'
	];
}
