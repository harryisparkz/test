<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Question extends Model
{
	 protected $table = 'wn_questions';
// protect from mass assignment vulnerabilities
    protected $fillable = [
	'description',
	'questiontype_id',
	'word_limit',
	'is_muliple',
	'marks',
	'answer_type',
	'status'
	];
}
