<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Category extends Model
{
    protected $table = 'wn_category';
	// protect from mass assignment vulnerabilities
	  protected $fillable = [
	'name',
	'description',
	'priority',
	'status'
	];
}
