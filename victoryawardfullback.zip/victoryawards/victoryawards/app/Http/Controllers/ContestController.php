<?php

namespace App\Http\Controllers;

use Request;

use App\Contest;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;
class ContestController extends Controller
{
	public $category;
	public $categories;
	  public function __construct()
     {
		$return = array(); 
        $this->category['data'] = DB::table('wn_category')->select('id', 'name')->get();
	    $count = count($this->category['data']);
		  for($i=0; $i < $count; $i++)
		  {
			  $data = $this->category['data'][$i];
			  $return[$data->id] = $data->name;
		  }
		$this->categories['categories'] = $return;
      }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
         $contests = Contest::all();
	
   
        return view('contests.index', compact('contests'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {

        return view('contests.create',$this->categories);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $input = Request::all();
	
		$validation = Validator::make($input,
		[
		'name' => 'required',
        'description' => 'required',
		'category' => 'required',
		'start_date' => 'required',
		'end_date' => 'required',
		'voting_start_date' => 'required',
		'voting_end_date' => 'required',
		
		//'image' => 'required|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
		]);
		if( $validation->fails() ) {
       return redirect('/contests/create')->withErrors($validation->errors());
			}
		else
		{
			
		if(isset($input['image']))
		{
			
		$imaged= new Contest;
		$file = $input['image'];
		$destination_path= public_path().'/images/' ;
		$Orname = $file->getClientOriginalName();
		$filename= str_random(6).'_'.$Orname;
		$file->move($destination_path,$filename);
		} else {
		$filename = "Default.jpg";
		}
	  
		$dataArray = array(
				"name" =>    $input['name'],
				"description" => $input['description'],
				"category" =>  json_encode($input['category']),
				"start_date" => $input['start_date'],
				"end_date" => $input['end_date'],
			    "voting_start_date" =>  $input['voting_start_date'],
		        "voting_end_date" =>  $input['voting_end_date'],
				"payment_type" => $input['payment_type'],
				"image" =>   $filename
		  );
		  
		
		
		Contest::create($dataArray);
		return redirect('contests');
	  }
    }

	/**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $contest = Contest::findOrFail($id);

        return view('contests.show', compact('contest'));
    }

	/**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    { 
	
	
	    $contest = Contest::findOrFail($id);
	
		$return = array(); 
		$main_cat_list = array();
		$getdata = DB::table('wn_category')->whereIn('id', json_decode($contest['category']))->get();
		$main_cat_list['selected'] = json_decode($contest['category']);
		$main_cat_list['all_categ'] = $this->categories;
		$category['categories']= $main_cat_list;
	
		return view('contests.edit', compact('contest'),$category);
    }


	/**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $contest = Contest::findOrFail($id);
        $input = Request::all();
		
		$validation = Validator::make($input,
       [
		'name' => 'required',
        'description' => 'required',
		'category' => 'required',
		'start_date' => 'required',
		'end_date' => 'required',
		'voting_start_date' => 'required',
		'voting_end_date' => 'required',
		//'image' => 'required|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
		]);
		if( $validation->fails() ) {
       return redirect('/contests/'.$id.'/edit')->withErrors($validation->errors());
      }
	  else
	  {
		if(isset($input['image']))
		{
			$imaged= new Contest;
			$file = $input['image'];
			$destination_path= public_path().'/images/' ;
			$Orname = $file->getClientOriginalName();
			$filename= str_random(6).'_'.$Orname;
			$file->move($destination_path,$filename);
		} else {
			$filename= isset($input['selected_image']) ? $input['selected_image'] : "Default.jpg" ;
		}
	
		$dataArray = array(
        "name" =>    $input['name'],
        "description" => $input['description'],
        "category" =>  json_encode($input['category']),
		"start_date" => $input['start_date'],
		"end_date" => $input['end_date'],
		"voting_start_date" =>  $input['voting_start_date'],
		"voting_end_date" =>  $input['voting_end_date'],
		"payment_type" => $input['payment_type'],
		"image" => $filename
		
        );
	
      
		$contest->update($dataArray);
		return redirect('contests');
	  }
	  
      
    }
	/**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
		

        $contest = Contest::findOrFail($id);
        $contest->delete();
        
    return redirect('contests');
    }
}
