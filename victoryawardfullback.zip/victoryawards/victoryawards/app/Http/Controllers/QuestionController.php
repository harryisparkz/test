<?php
namespace App\Http\Controllers;

use Request;
use App\Question;
use Illuminate\Support\Facades\Validator;


class QuestionController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $questions = Question::all();
	
   
        return view('questions.index', compact('questions'));
    }

/**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('questions.create');
    }

/**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $input = Request::all();
	  
		$validation = Validator::make($input,
       [
        'description' => 'required',
		'questiontype_id' => 'required|integer',
        'word_limit' => 'required|integer',
        'marks' => 'required|integer',
		'answer_type'=> 'required',
		]);
		if( $validation->fails() ) {
       return redirect('/questions/create')->withErrors($validation->errors());
      }
	  else
	  {
      Question::create($input);
	return redirect('questions');
	  }
    }

/**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $question = Question::findOrFail($id);

        return view('questions.show', compact('question'));
    }

/**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
	    $question = Question::findOrFail($id);
        return view('questions.edit', compact('question'));
    }

/**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $question = Question::findOrFail($id);
        $input = Request::all();
		
		$validation = Validator::make($input,
       [
        'description' => 'required',
		'questiontype_id' => 'required|integer',
        'word_limit' => 'required|integer',
		'marks' => 'required|integer',
		'answer_type'=> 'required',
		]);
		if( $validation->fails() ) {
       return redirect('/questions/'.$id.'/edit')->withErrors($validation->errors());
      }
	  else
	  {
		$question->update($input);
		return redirect('questions');
	  }
	  
      
    }

/**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
	
        $question = Question::findOrFail($id);
        $question->delete();
        
        return redirect('questions');
    }
}
