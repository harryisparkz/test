<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;
use App\wn_users as wn_users;
use Hash;

class AdminUser extends Controller
{
	/**
	 * Function for list new comming user for activation 
	 * Date :- 20-march-17
	 */

    public function newUserlist()
    {
    	$userList['details'] = wn_users::where("status", "=", "0")->get();
    	return view('userfiles.new-user-list', $userList);
    }

    /**
	 * Function for list Activated user list
	 * Date :- 20-march-17
	 */
    public function listsUser()
    {
    	$userList['details'] = wn_users::where("status", "=", "1")
                            ->orWhere("status", "=", "2")->get();
    	return view('userfiles.user-list', $userList);
    }

    /**
     * Function for activate user 
     * Date :- 22-march-17
     */
    public function activateUser($id)
    {
        $update = wn_users ::where('user_id', $id)->update(array('status' => 1));
        if($update == 1)
        {
            return redirect('/user-list');
        }
    }

    /**
     * Function for De-activate user 
     * Date :- 22-march-17
     */
    public function deActivateUser($id)
    {
        $update = wn_users ::where('user_id', $id)->update(array('status' => 2));
        if($update == 1)
        {
            return redirect('/user-list');
        }
    }

    /**
     * Function for Create new user account by super admin 
     * Date :- 23-march-17
     */

    public function addUser(Request $request)
    {
        $country['data'] = DB::table('wn_country')->select('country_id', 'countries_name')->get();
        if(isset($_POST['submit']))
        {
            $host = $_SERVER["REMOTE_ADDR"]; /* Code for getting user ip address */
            
            /* Validation condition */
            $validation = Validator::make($request->all(),
            [
                'firstname' => 'required',
                'lastname' => 'required',
                'username' => 'required',
                'email' => 'required|email|unique:wn_users',
                'password' => 'required|min:6',
                'company' => 'required',
                'country' => 'required',
                'discription' => 'required',
            ]
        );

            if( $validation->fails() ) {
                return redirect('/addUser')->withErrors($validation->errors());
            }
            else {

                $userdata = $request->all(); /* Getting all user form data */

                /* Generating user-data array */
                $dataArray = array(
                    "role_id" => 4,
                    "firstname" => $userdata['firstname'],
                    "lastname" => $userdata['lastname'],
                    "username" => $userdata['username'],
                    "email" => $userdata['email'],
                    "password" => Hash::make($userdata['password']),
                    "companyname" => $userdata['company'],
                    "country_id" => $userdata['country'],
                    "description" => $userdata['discription'],
                    "ip" => $host,
                    "update_date" => date('Y-m-d'),
                    "status" => "0"
                    );
 
                $insert = wn_users::create($dataArray); /* Insert into database */
                $insert->save();
            }
        }
        return view('userfiles.addform', $country);
    }

    /**
     * Function for View User Details
     * Date :- 23-march-17
     */

    function userDetails($id)
    {
        if(isset($id) && !empty($id))
        {
            $userData['value'] = wn_users::where("user_id", "=", $id)
                        ->join('wn_role', 'wn_role.role_id', '=', 'wn_users.role_id')
                        ->join('wn_country', 'wn_country.country_id', '=', 'wn_users.country_id')
                        ->select('wn_users.*', 'wn_country.countries_name', 'wn_role.name')
                        ->get()->toArray();
            
        }
        return view('userfiles.userview', $userData);
    }
}
