<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use Hash;
use App\wn_users as wn_users;

class UserController extends Controller
{
	/**
	 * Function for user registration 
	 * Date :- 18-march-2016
	 * Modify :- 22-march-2017
	 */
	public function registration(Request $request)
    {
    	/* Getting all countries data from database */
    	$country['data'] = DB::table('wn_country')->select('country_id', 'countries_name')->get();
    	
    	if(isset($_POST['submit'])) 
    	{
    		$host = $_SERVER["REMOTE_ADDR"]; /* Code for getting user ip address */
    		
    		/* Validation condition */
			$validation = Validator::make($request->all(),
    		[
			    'firstname' => 'required',
			    'lastname' => 'required',
			    'username' => 'required',
			    'email' => 'required|email|unique:wn_users',
			    'password' => 'required|min:6',
			    'passwordsignup_confirm' => 'required|min:6',
			    'company' => 'required',
			    'country' => 'required',
			    'discription' => 'required',
			]
	    );

	    	if( $validation->fails() ) {
	    		return redirect('/registration#toregister')->withErrors($validation->errors());
	    	}
	    	else {

	    		$userdata = $request->all(); /* Getting all user form data */

	    		/* Generating user-data array */
	    		$dataArray = array(
	    			"role_id" => 4,
	    			"firstname" => $userdata['firstname'],
	    			"lastname" => $userdata['lastname'],
	    			"username" => $userdata['username'],
	    			"email" => $userdata['email'],
	    			"password" => Hash::make($userdata['password']),
	    			"companyname" => $userdata['company'],
	    			"country_id" => $userdata['country'],
	    			"description" => $userdata['discription'],
	    			"ip" => $host,
	    			"update_date" => date('Y-m-d'),
	    			"status" => "0"
	    			);
 
	    		$insert = wn_users::create($dataArray); /* Insert into database */
	    		$insert->save();
	    	}
	    	
    	}

		return view('user-reg-login', $country);
    }

    /**
	 * Function for user Login 
	 * Date :- 20-march-2017
	 */

    public function login(Request $request)
    {
    	$input = $request->all();
    	$validation = Validator::make($input, [
    		'username' => 'required',
			'password' => 'required|min:6',
			]);

    	if( $validation->fails() ) {
    		return redirect('/registration#tologin')->withErrors($validation->errors());
    	}
    	else {
    		$userdata = array(
		        'email'     => $input['username'],
		        'password'  => Hash::make($input['password'])
		    );
    		$return = wn_users::check($userdata);
		    if (!empty($return)) { 
		    	if($return[0]['status'] == 0)
		    	{
		    		//die('here');
		    		return redirect('/registration#tologin')->with('message', 'Membership - Registration waiting for approval ');
 				}
				else
				{
					echo "Logedin successfully ....";
				}
		    }
		    else
		    {
		    	echo "Login Failled ...";
		    }
		}
    }

}
