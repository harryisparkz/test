<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;
use Hash;
use App\wn_users as wn_users;

class UserController extends Controller
{
   public function registration(Request $request)
    {
    	$array = $request->all();
    	if(isset($_POST['submit'])) 
    	{
	    		$validation = Validator::make($request->all(),
	    		[
				    'firstname' => 'required',
				    'email' => 'required|email|unique:wn_users',
				    'password' => 'required|min:6',
				    'passwordsignup_confirm' => 'required|min:6',
				]
	    	);

	    	if( $validation->fails() ) {
	    		return redirect('/registration#toregister')->withErrors($validation->errors());
	    	}
	    	else {
	    		$userdata = $request->all();
	    		$dataArray = array(
	    			"role_id" => 1,
	    			"firstname" => $userdata['firstname'],
	    			"lastname" => "--",
	    			"username" => $userdata['firstname'],
	    			"email" => $userdata['email'],
	    			"password" => Hash::make($userdata['password']),
	    			"companyname" => "Imax",
	    			"country_id" => "123",
	    			"description" => "Testing",
	    			"ip" => "192.168.1.1",
	    			"update_date" => date('Y-m-d'),
	    			"status" => "0"
	    			);

	    		$insert = wn_users::create($dataArray);
	    		$insert->save();
	    	}
	    	
    	}

		return view('user-reg-login');
    }

    public function login(Request $request)
    {
    	$input = $request->all();
    	$validation = Validator::make($input, [
    		'username' => 'required',
			'password' => 'required|min:6',
			]);

    	if( $validation->fails() ) {
    		return redirect('/registration#tologin')->withErrors($validation->errors());
    	}
    	else {
    		$userdata = array(
		        'email'     => $input['username'],
		        'password'  => Hash::make($input['password'])
		    );
    		$return = wn_users::check($userdata);
		    if (!empty($return)) { 
				echo "Success";
		    }
		    else
		    {
		    	echo "Login Failled ...";
		    }
		}
    }

}
