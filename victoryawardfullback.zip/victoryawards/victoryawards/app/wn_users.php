<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class wn_users extends Model
{

	/**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'wn_users';
    public $timestamps = false;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'role_id','firstname', 'lastname', 'username', 'email', 'password', 'companyname', 'country_id', 'description', 'ip', 'update_date', 'status'
    ];

    /**
     * Function for check user data for login user 
     *
     * @var array
     */
    Protected function check($userdata)
    {
    	$data = $this->where("email", "=", $userdata['email'])
    			->orWhere("password", "=", $userdata['password'])
    			->get()
    			->toArray();

    	if(isset($data) && !empty($data)) {
    		return $data;
    	}
    	else {
    		return false;
    	}
    }

}
