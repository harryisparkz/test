<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('dashboard');
});

Route::get('/new-user-account', 'adminUser@newUserlist'); /* Routing for new user list in super admin panel */
Route::get('/user-list', 'adminUser@listsUser'); /* Routing for list user in super admin panel */
Route::get('/activate/{id}', 'adminUser@activateUser'); /* Routing for activate user by super admin */
Route::get('/deactivate/{id}', 'adminUser@deActivateUser'); /* Routing for De-activate user by super admin */
Route::any('/addUser', 'adminUser@addUser'); /* Routing for add user by super admin */
Route::any('/displayUser/{id}', 'adminUser@userDetails'); /* Routing for display user details */

Auth::routes();

Route::get('/dashboard', 'HomeController@index');
Route::any('/registration', 'UserController@registration'); /* Routing for user registration */

Route::any('/user-login', "UserController@login"); /* Routing for user login */


/* Question Section Start */
Route::resource('questions', 'QuestionController');
/* Question Section End */
/* Category Section Start */
Route::resource('categories', 'CategoryController');
/* Category Section End */
/* Contest Section Start */
Route::resource('contests', 'ContestController');
/* Contest Section End */