<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
        <div class="page-title">
          <div>
            <h1>New User List</h1>
            <ul class="breadcrumb side">
              <li><i class="fa fa-home fa-lg"></i></li>
              <li>Tables</li>
              <li class="active"><a href="#">User List</a></li>
            </ul>
          </div>
          <div><a class="btn btn-primary btn-flat" href="<?php echo e(url('/addUser')); ?>"><i class="fa fa-lg fa-plus"></i></a><a class="btn btn-info btn-flat" href="#"><i class="fa fa-lg fa-refresh"></i></a><a class="btn btn-warning btn-flat" href="#"><i class="fa fa-lg fa-trash"></i></a></div>
        </div>
        <div class="row">
          <div class="col-md-12">
            <div class="card">
              <div class="card-body">
                <table class="table table-hover table-bordered" id="sampleTable">
                  <thead>
                    <tr>
                      <th>S.no</th>
                      <th>Firstname</th>
                      <th>Lastname</th>
                      <th>Email</th>
                      <th>Discription</th>
                      <th><font color="red">Action</font></th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php if(!empty($details)): ?>
                    <?php $__currentLoopData = $details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
                    <tr>
                      <td><?php echo e($key+1); ?></td>
                      <td><?php echo e($val['firstname']); ?></td>
                      <td><?php echo e($val['lastname']); ?></td>
                      <td><?php echo e($val['email']); ?></td>
                      <td><?php echo e($val['description']); ?></td> 
                      <td><a href="<?php echo e(url('/displayUser')); ?>/<?php echo e($val['user_id']); ?>" class="btn btn-default">View</a><a href="<?php echo e(url('/activate')); ?>/<?php echo e($val['user_id']); ?>" class="btn btn-success">Activate</a></td>
                    </tr>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   <?php endif; ?> 
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
      <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>