<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
        <div class="page-title">
          <div>
            <h1><i class="fa fa-edit"></i> Add User Form</h1>
            <p>Form component for add new users</p>
          </div>
          <div>
            <ul class="breadcrumb">
              <li><i class="fa fa-home fa-lg"></i></li>
              <li>Forms</li>
              <li><a href="#">User Form</a></li>
            </ul>
          </div>
        </div>
        <div class="row">
          <div class="col-md-12">
            <div class="card">
              <div class="row">
                <div class="col-lg-10">
                  <div class="well bs-component">
                    <form class="form-horizontal" action="<?php echo e(url('/addUser')); ?>" method="POST" id="adminAddUser">
                      <?php echo e(csrf_field()); ?>

                      <fieldset>
                        <legend> Add Details</legend>
                        <div class="form-group">
                          <label class="col-lg-2 control-label" for="fname">First Name</label>
                          <div class="col-lg-10">
                            <input class="form-control" id="fname" type="text" placeholder="First Name" name="firstname">
                             <?php if($errors->has('firstname')): ?><p style="color:red;"><?php echo $errors->first('firstname'); ?></p><?php endif; ?>
                          </div>
                        </div>
                        <div class="form-group">
                          <label class="col-lg-2 control-label" for="fname">Last Name</label>
                          <div class="col-lg-10">
                            <input class="form-control" id="lname" type="text" placeholder="Last Name" name="lastname">
                             <?php if($errors->has('lastname')): ?><p style="color:red;"><?php echo $errors->first('lastname'); ?></p><?php endif; ?>
                          </div>
                        </div>
                        <div class="form-group">
                          <label class="col-lg-2 control-label" for="user-name">User Name</label>
                          <div class="col-lg-10">
                            <input class="form-control" id="username" type="text" placeholder="User-Name" name="username">
                             <?php if($errors->has('username')): ?><p style="color:red;"><?php echo $errors->first('username'); ?></p><?php endif; ?>
                          </div>
                        </div>
                        <div class="form-group">
                          <label class="col-lg-2 control-label" for="inputEmail">Email</label>
                          <div class="col-lg-10">
                            <input class="form-control" id="inputEmail" type="email" placeholder="Email" name="email">
                             <?php if($errors->has('email')): ?><p style="color:red;"><?php echo $errors->first('email'); ?></p><?php endif; ?>
                          </div>
                        </div>
                        <div class="form-group">
                          <label class="col-lg-2 control-label" for="inputPassword">Password</label>
                          <div class="col-lg-10">
                            <input class="form-control" id="inputPassword" type="password" placeholder="Password" name="password">
                             <?php if($errors->has('password')): ?><p style="color:red;"><?php echo $errors->first('password'); ?></p><?php endif; ?>
                          </div>
                        </div>
                        <div class="form-group">
                          <label class="col-lg-2 control-label" for="company-name">Company Name</label>
                          <div class="col-lg-10">
                            <input class="form-control" id="company" type="text" placeholder="Company Name" name="company">
                             <?php if($errors->has('company')): ?><p style="color:red;"><?php echo $errors->first('company'); ?></p><?php endif; ?>
                          </div>
                        </div>
                        <div class="form-group">
                          <label class="col-lg-2 control-label" for="select">Country</label>
                          <div class="col-lg-10">
                            <select class="form-control" id="select" name="country">
                              <option value="">Select Country</option>
                                        <?php if(isset($data) && !empty($data)): ?>
                                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($val->country_id); ?>"><?php echo e($val->countries_name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                              <?php if($errors->has('country')): ?><p style="color:red;"><?php echo $errors->first('country'); ?></p><?php endif; ?>
                            </select>
                           </div>
                        </div>
                        <div class="form-group">
                          <label class="col-lg-2 control-label" for="discription">Discription</label>
                          <div class="col-lg-10">
                            <textarea class="form-control" id="discription" rows="3" name="discription"></textarea>
                             <?php if($errors->has('discription')): ?><p style="color:red;"><?php echo $errors->first('discription'); ?></p><?php endif; ?>
                          </div>
                        </div>
                        <div class="form-group">
                          <div class="col-lg-10 col-lg-offset-2">
                            <button class="btn btn-default" type="reset">Cancel</button>
                            <button class="btn btn-primary" type="submit" name="submit" value="submit">Submit</button>
                          </div>
                        </div>
                      </fieldset>
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>