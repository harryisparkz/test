 <fieldset>
 <legend>Category</legend>
<?php echo e(csrf_field()); ?>

			<div class='form-group'>
				<?php echo Form::label('name', 'Name:',['class' => 'col-lg-2 control-label']); ?>

				<div class="col-lg-10">
				<?php echo Form::text('name', null, ['class' => 'form-control', 'id' => 'name']); ?>

				<?php if($errors->has('name')): ?>
					<p style="color:red;">
					<?php echo $errors->first('name'); ?>

					</p>
				<?php endif; ?>
				</div>
			</div>
			<div class='form-group'>
				<?php echo Form::label('description', 'Description:',['class' => 'col-lg-2 control-label']); ?>

				<div class="col-lg-10">
				<?php echo Form::textarea('description', null, ['class' => 'form-control', 'id' => 'description']); ?>

				<?php if($errors->has('description')): ?>
					<p style="color:red;">
					<?php echo $errors->first('description'); ?>

					</p>
				<?php endif; ?>
				</div>
			</div>
			
	
		<div class='form-group'>
			<?php echo Form::label('priority', 'Priority:',['class' => 'col-lg-2 control-label']); ?>

				<div class="col-lg-10">
			<?php echo Form::text('priority', null, ['class' => 'form-control', 'id' => 'priority']); ?>

				<?php if($errors->has('priority')): ?>
					<p style="color:red;">
					<?php echo $errors->first('priority'); ?>

					</p>
				<?php endif; ?>
				</div>
		</div>
	
		<div class='form-group'>
			<?php echo Form::label('status', 'Status:',['class' => 'col-lg-2 control-label']); ?>

				<div class="col-lg-10">
			<?php echo Form::select('status',  ['1' => 'Enable', '0' => 'Disable'],null, ['class' => 'form-control', 'id' => 'status']); ?>

				<?php if($errors->has('status')): ?>
					<p style="color:red;">
					<?php echo $errors->first('status'); ?>

					</p>
				<?php endif; ?>
				</div>
		</div>
		
		
		 


<script>
var input, autocomplete;

function initialize() {

	input = document.getElementById('location');
	autocomplete = new google.maps.places.Autocomplete(input);
}

google.maps.event.addDomListener(window, 'load', initialize);

function createCandidate(a, b, c){
	var name = document.getElementById("name").value;
	var email = document.getElementById("email").value;
	var phone = document.getElementById("phone").value;

	// var place = autocomplete.getPlace();
	// console.log(place);

	// var latitude = place.geometry.location.lat();
	// var longitude = place.geometry.location.lng();
	// console.log(latitude, longitude);



}

function editCandidate(){
	console.log('edit form submitted!');
}
</script>

<div class='form-group'>
    <div class="col-lg-10 col-lg-offset-2">
	 <a href="<?php echo e(url('categories')); ?>" class="btn btn-default" >Cancel</a>
	<?php echo Form::submit($submitButtonText, ['class' => 'btn btn-primary']); ?>

	</div>
</div>
  </fieldset>