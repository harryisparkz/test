<?php $__env->startSection('content'); ?>


<div class="content-wrapper">
        <div class="page-title">
          <div>
            <h1><i class="fa fa-edit"></i>Add Category</h1>
            <p>Add New Category</p>
          </div>
          <div>
            <ul class="breadcrumb">
              <li><i class="fa fa-home fa-lg"></i></li>
              <li>Category Section</li>
              <li><a href="#">Add Category</a></li>
            </ul>
          </div>
        </div>
        <div class="row">
          <div class="col-md-12">
            <div class="card">
              <div class="row">
                <div class="col-lg-10">
                  <div class="well bs-component">
				  
<?php echo Form::open(['action' => 'CategoryController@store','class'=>'form-horizontal', 'id' =>'categoryForm']); ?>

   <?php echo $__env->make('categories.form', ['submitButtonText' => 'Add Category'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo Form::close(); ?>

	
	
				</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>