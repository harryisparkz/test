<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
        <div class="page-title">
          <div>
            <h1><i class="fa fa-th-list"></i> User Details</h1>
            <p> Table for display user details</p>
          </div>
          <div>
            <ul class="breadcrumb">
              <li><i class="fa fa-home fa-lg"></i></li>
              <li>Tables</li>
              <li class="active"><a href="#">Simple Tables</a></li>
            </ul>
          </div>
        </div>
       <div class="clearfix"></div>
          <div class="col-md-12">
            <div class="card">
              <h3 class="card-title">User Details</h3>
              <div class="table-responsive">
                <table class="table">
                 <tbody>
                  <?php if(!empty($value)): ?>
                    <tr><td><strong>First Name</strong></td><td><?php echo e($value[0]['firstname']); ?></td></tr>
                      <tr><td><strong>Last Name</strong></td><td><?php echo e($value[0]['lastname']); ?></td></tr>
                      <tr><td><strong>Username</strong></td><td><?php echo e($value[0]['username']); ?></td></tr>
                      <tr><td><strong>Email</strong></td><td><?php echo e($value[0]['email']); ?></td></tr>
                      <tr><td><strong>Company Name</strong></td><td><?php echo e($value[0]['companyname']); ?></td></tr>
                      <tr><td><strong>Discription</strong></td><td><?php echo e($value[0]['description']); ?></td></tr>
                      <tr><td><strong>Country</strong></td><td><?php echo e($value[0]['countries_name']); ?></td></tr>
                      <tr><td><strong>Role</strong></td><td><?php echo e($value[0]['name']); ?></td></tr>
                  <?php else: ?>
                  <tr><td><font color="red">No Record Found...!!</font></td></tr>
                  <?php endif; ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>