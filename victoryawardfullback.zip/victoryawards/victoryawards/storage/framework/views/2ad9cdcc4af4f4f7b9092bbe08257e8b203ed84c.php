 <fieldset>
 <legend>Contest</legend>
<?php echo e(csrf_field()); ?>

		<div class='form-group'>
				<?php echo Form::label('name', 'Name:',['class' => 'col-lg-2 control-label']); ?>

				<div class="col-lg-10">
				<?php echo Form::text('name', null, ['class' => 'form-control', 'id' => 'name']); ?>

				<?php if($errors->has('name')): ?>
					<p style="color:red;">
					<?php echo $errors->first('name'); ?>

					</p>
				<?php endif; ?>
				</div>
			</div>
			<div class='form-group'>
				<?php echo Form::label('description', 'Description:',['class' => 'col-lg-2 control-label']); ?>

				<div class="col-lg-10">
				<?php echo Form::textarea('description', null, ['class' => 'form-control', 'id' => 'description']); ?>

				<?php if($errors->has('description')): ?>
					<p style="color:red;">
					<?php echo $errors->first('description'); ?>

					</p>
				<?php endif; ?>
				</div>
			</div>
			<div class='form-group'>
				<?php echo Form::label('start_date', 'Start Date:',['class' => 'col-lg-2 control-label']); ?>

				<div class="col-lg-10">
				<?php echo Form::text('start_date',null, ['class' => 'form-control', 'id' => 'start_date']); ?>

				<?php if($errors->has('start_date')): ?>
					<p style="color:red;">
					<?php echo $errors->first('start_date'); ?>

					</p>
				<?php endif; ?>
				</div>
			</div>
			<div class='form-group'>
				<?php echo Form::label('end_date', 'End Date:',['class' => 'col-lg-2 control-label']); ?>

				<div class="col-lg-10">
				<?php echo Form::text('end_date',null, ['class' => 'form-control', 'id' => 'end_date']); ?>

				<?php if($errors->has('end_date')): ?>
					<p style="color:red;">
					<?php echo $errors->first('end_date'); ?>

					</p>
				<?php endif; ?>
				</div>
			</div>
			<div class='form-group'>
				<?php echo Form::label('voting_start_date', 'Voting Start Date:',['class' => 'col-lg-2 control-label']); ?>

				<div class="col-lg-10">
				<?php echo Form::text('voting_start_date',null, ['class' => 'form-control', 'id' => 'voting_start_date']); ?>

				<?php if($errors->has('voting_start_date')): ?>
					<p style="color:red;">
					<?php echo $errors->first('voting_start_date'); ?>

					</p>
				<?php endif; ?>
				</div>
			</div>
			<div class='form-group'>
				<?php echo Form::label('voting_end_date', 'Voting End Date:',['class' => 'col-lg-2 control-label']); ?>

				<div class="col-lg-10">
				<?php echo Form::text('voting_end_date',null, ['class' => 'form-control', 'id' => 'voting_end_date']); ?>

				<?php if($errors->has('voting_end_date')): ?>
					<p style="color:red;">
					<?php echo $errors->first('voting_end_date'); ?>

					</p>
				<?php endif; ?>
				</div>
			</div>
			
			
			
			<div class='form-group'>
				<?php echo Form::label('category', 'Category Select:',['class' => 'col-lg-2 control-label']); ?>

				<div class="col-lg-10">
				<?php if(array_key_exists("selected",$categories) ): ?>
				<?php echo e(Form::select('category[]', $categories['all_categ']['categories'], Request::old('category') ? Request::old('category') : $categories['selected'], array('multiple' => true))); ?>

				<?php else: ?>
				<?php echo Form::select('category[]', $categories, null, ['multiple' => true], ['class' => 'form-control', 'id' => 'category']); ?>

				<?php endif; ?>
				<?php if($errors->has('category')): ?>
					<p style="color:red;">
					<?php echo $errors->first('category'); ?>

					</p>
				<?php endif; ?>
				</div>
			</div>
		
		<div class='form-group'>
			<?php echo Form::label('payment_type', 'Payment Type:',['class' => 'col-lg-2 control-label']); ?>

				<div class="col-lg-10">
			<?php echo Form::select('payment_type',  ['0' => 'Free', '1' => 'Paid'],null, ['class' => 'form-control', 'id' => 'payment_type']); ?>

				<?php if($errors->has('payment_type')): ?>
					<p style="color:red;">
					<?php echo $errors->first('payment_type'); ?>

					</p>
				<?php endif; ?>
				</div>
		</div>
		<div class='form-group'>
			<?php echo Form::label('image', 'Image:',['class' => 'col-lg-2 control-label']); ?>

				<div class="col-lg-10">
			<?php echo Form::file('image',  null,['class' => 'form-control', 'id' => 'image']); ?>

			<?php echo e(Form::hidden('selected_image',isset( $contest['image']) ?  $contest['image'] : 'Default.jpg')); ?>

            <img src="<?php echo e(url('/public/images')); ?>/<?php echo e(isset( $contest['image']) ?  $contest['image'] : 'Default.jpg'); ?> " height="100px" width="100px" alt="default-img">
				
				<?php if($errors->has('image')): ?>
					<p style="color:red;">
					<?php echo $errors->first('image'); ?>

					</p>
				<?php endif; ?>
				</div>
		</div>
			
		<div class='form-group'>
			<?php echo Form::label('status', 'Status:',['class' => 'col-lg-2 control-label']); ?>

				<div class="col-lg-10">
			<?php echo Form::select('status',  ['1' => 'Published', '0' => 'Not-Published'],null, ['class' => 'form-control', 'id' => 'status']); ?>

				<?php if($errors->has('status')): ?>
					<p style="color:red;">
					<?php echo $errors->first('status'); ?>

					</p>
				<?php endif; ?>
				</div>
		</div>
		
		
		 


<script>
var input, autocomplete;

function initialize() {

	input = document.getElementById('location');
	autocomplete = new google.maps.places.Autocomplete(input);
}

google.maps.event.addDomListener(window, 'load', initialize);

function createCandidate(a, b, c){
	var name = document.getElementById("name").value;
	var email = document.getElementById("email").value;
	var phone = document.getElementById("phone").value;

	// var place = autocomplete.getPlace();
	// console.log(place);

	// var latitude = place.geometry.location.lat();
	// var longitude = place.geometry.location.lng();
	// console.log(latitude, longitude);



}

function editCandidate(){
	console.log('edit form submitted!');
}
</script>

<div class='form-group'>
    <div class="col-lg-10 col-lg-offset-2">
	 <button class="btn btn-default" type="reset">Cancel</button>
	<?php echo Form::submit($submitButtonText, ['class' => 'btn btn-primary']); ?>

	</div>
</div>
  </fieldset>