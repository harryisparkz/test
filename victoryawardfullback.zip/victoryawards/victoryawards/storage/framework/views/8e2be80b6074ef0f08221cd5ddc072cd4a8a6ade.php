 <fieldset id="fieldset_id">
 <legend>Question</legend>
<?php echo e(csrf_field()); ?>

			<div class='form-group'>
				<?php echo Form::label('description', 'Description:',['class' => 'col-lg-2 control-label']); ?>

				<div class="col-lg-10">
				<?php echo Form::textarea('description', null, ['class' => 'form-control', 'id' => 'description']); ?>

				<?php if($errors->has('description')): ?>
					<p style="color:red;">
					<?php echo $errors->first('description'); ?>

					</p>
				<?php endif; ?>
				</div>
			</div>
		<!-- 	<div class='form-group'>
				<?php echo Form::label('questiontype_id', 'Question Type:',['class' => 'col-lg-2 control-label']); ?>

				<div class="col-lg-10">
				<?php echo Form::text('questiontype_id', null, ['class' => 'form-control', 'id' => 'questiontype_id']); ?>

				<?php if($errors->has('questiontype_id')): ?>
					<p style="color:red;">
					<?php echo $errors->first('questiontype_id'); ?>

					</p>
				<?php endif; ?>
				</div>
			</div>
 -->
		    <div class='form-group'>
			<?php echo Form::label('questiontype_id', 'Question Type:',['class' => 'col-lg-2 control-label']); ?>

				<div class="col-lg-10">
			<?php echo Form::select('questiontype_id',  ['1' => 'Text', '2' => 'Radio', '3' => 'Checkbox', '4' => 'Select', '5' => 'Textarea', '7' => 'number', '8' => 'Email', '9' => 'Url', '10' => 'Date', '11' => 'File', '12' => 'Button', '13' => 'Tel', '14' => 'Hidden', '15' => 'Image'],null, ['class' => 'form-control', 'id' => 'questiontype_id']); ?>

				<?php if($errors->has('questiontype_id')): ?>
					<p style="color:red;">
					<?php echo $errors->first('questiontype_id'); ?>

					</p>
				<?php endif; ?>
				</div>
		    </div>

	
		<div class='form-group'>
			<?php echo Form::label('word_limit', 'Word Limit:',['class' => 'col-lg-2 control-label']); ?>

				<div class="col-lg-10">
			<?php echo Form::text('word_limit', null, ['class' => 'form-control', 'id' => 'word_limit']); ?>

				<?php if($errors->has('word_limit')): ?>
					<p style="color:red;">
					<?php echo $errors->first('word_limit'); ?>

					</p>
				<?php endif; ?>
				</div>
		</div>
		<div class='form-group'>
			<?php echo Form::label('is_muliple', 'Is Muliple:',['class' => 'col-lg-2 control-label']); ?>

				<div class="col-lg-10">
			<?php echo Form::select('is_muliple',['0' => 'No', '1' => 'Yes'], null, ['class' => 'form-control', 'id' => 'is_muliple']); ?>

				<?php if($errors->has('is_muliple')): ?>
					<p style="color:red;">
					<?php echo $errors->first('is_muliple'); ?>

					</p>
				<?php endif; ?>
				</div>
		</div>
		<div class='form-group'>
			<?php echo Form::label('marks', 'Marks:',['class' => 'col-lg-2 control-label']); ?>

				<div class="col-lg-10">
			<?php echo Form::text('marks', null, ['class' => 'form-control', 'id' => 'marks']); ?>

				<?php if($errors->has('marks')): ?>
					<p style="color:red;">
					<?php echo $errors->first('marks'); ?>

					</p>
				<?php endif; ?>
				</div>
		</div>
		<div class='form-group'>
			<?php echo Form::label('answer_type', 'Answer Type:',['class' => 'col-lg-2 control-label']); ?>

				<div class="col-lg-10">
			<?php echo Form::text('answer_type', null, ['class' => 'form-control', 'id' => 'answer_type']); ?>

				<?php if($errors->has('answer_type')): ?>
					<p style="color:red;">
					<?php echo $errors->first('answer_type'); ?>

					</p>
				<?php endif; ?>
				</div>
		</div>
		<div class='form-group'>
			<?php echo Form::label('status', 'Status:',['class' => 'col-lg-2 control-label']); ?>

				<div class="col-lg-10">
			<?php echo Form::select('status',  ['1' => 'Enable', '0' => 'Disable'],null, ['class' => 'form-control', 'id' => 'status']); ?>

				<?php if($errors->has('status')): ?>
					<p style="color:red;">
					<?php echo $errors->first('status'); ?>

					</p>
				<?php endif; ?>
				</div>
		</div>
		
		
		 


<script>
var input, autocomplete;

function initialize() {

	input = document.getElementById('location');
	autocomplete = new google.maps.places.Autocomplete(input);
}

google.maps.event.addDomListener(window, 'load', initialize);

function createCandidate(a, b, c){
	var name = document.getElementById("name").value;
	var email = document.getElementById("email").value;
	var phone = document.getElementById("phone").value;

	// var place = autocomplete.getPlace();
	// console.log(place);

	// var latitude = place.geometry.location.lat();
	// var longitude = place.geometry.location.lng();
	// console.log(latitude, longitude);



}

function editCandidate(){
	console.log('edit form submitted!');
}
</script>

<div class='form-group'>
    <div class="col-lg-10 col-lg-offset-2">
	 <button class="btn btn-default" type="reset">Cancel</button>
	<?php echo Form::submit($submitButtonText, ['class' => 'btn btn-primary']); ?>

	</div>
</div>
  </fieldset>
