<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
        <div class="page-title">
          <div>
            <h1><i class="fa fa-edit"></i>Show Question</h1>
            <p>Show Question</p>
          </div>
          <div>
            <ul class="breadcrumb">
              <li><i class="fa fa-home fa-lg"></i></li>
              <li>Question Section</li>
              <li><a href="#">Show Question</a></li>
            </ul>
          </div>
        </div>
        <div class="row">
          <div class="col-md-12">
            <div class="card">
              <div class="row">
                <div class="col-lg-10">
                  <div class="well bs-component">
				  <?php echo Form::open(['class'=>'form-horizontal']); ?>

				   <fieldset>
					<legend>Question</legend>
				  <?php echo e(csrf_field()); ?>

			<div class='form-group'>
				<?php echo Form::label('name', 'Name:',['class' => 'col-lg-2 control-label']); ?>

				<div class="col-lg-10">
				<?php echo e($contest->name); ?>

				</div>
			</div>
			<div class='form-group'>
				<?php echo Form::label('description', 'Description:',['class' => 'col-lg-2 control-label']); ?>

				<div class="col-lg-10">
				<?php echo e($contest->description); ?>

				</div>
			</div>
			
			
				  </fieldset>
				  
				    <?php echo Form::close(); ?>

					
		</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
	  
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>