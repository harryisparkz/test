<?php $__env->startSection('content'); ?>

<div class="content-wrapper">
        <div class="page-title">
          <div>
            <h1><i class="fa fa-edit"></i>Edit Contest</h1>
            <p>Update Contest</p>
          </div>
          <div>
            <ul class="breadcrumb">
              <li><i class="fa fa-home fa-lg"></i></li>
              <li>Contest Section</li>
              <li><a href="#">Edit Contest</a></li>
            </ul>
          </div>
        </div>
        <div class="row">
          <div class="col-md-12">
            <div class="card">
              <div class="row">
                <div class="col-lg-10">
                  <div class="well bs-component">
		
		<?php echo Form::model($contest, ['method' => 'PATCH', 'action' => ['ContestController@update',$contest->id],'class'=>'form-horizontal','files'=>true]); ?>

			<?php echo $__env->make('contests.form', ['submitButtonText' => 'Edit Contest'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<?php echo Form::close(); ?>

				</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>