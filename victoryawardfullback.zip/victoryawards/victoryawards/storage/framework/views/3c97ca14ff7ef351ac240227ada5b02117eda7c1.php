<?php $__env->startSection('content'); ?>

<div class="content-wrapper">
        <div class="page-title">
          <div>
            <h1><i class="fa fa-edit"></i>Edit Question</h1>
            <p>Update Question</p>
          </div>
          <div>
            <ul class="breadcrumb">
              <li><i class="fa fa-home fa-lg"></i></li>
              <li>Question Section</li>
              <li><a href="#">Edit Question</a></li>
            </ul>
          </div>
        </div>
        <div class="row">
          <div class="col-md-12">
            <div class="card">
              <div class="row">
                <div class="col-lg-10">
                  <div class="well bs-component">
		
		<?php echo Form::model($question, ['method' => 'PATCH', 'action' => ['QuestionController@update',$question->id],'class'=>'form-horizontal']); ?>

			<?php echo $__env->make('questions.form', ['submitButtonText' => 'Edit Question'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<?php echo Form::close(); ?>

				</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>