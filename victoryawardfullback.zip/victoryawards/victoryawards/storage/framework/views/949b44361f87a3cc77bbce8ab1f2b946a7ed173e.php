<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
        <div class="page-title">
          <div>
            <h1>Contests Section</h1>
            <ul class="breadcrumb side">
              <li><i class="fa fa-home fa-lg"></i></li>
              <li>Contests</li>
              <li class="active"><a href="#">Contests Section</a></li>
            </ul>
          </div>
          <div><a class="btn btn-primary btn-flat" href="<?php echo e(url('contests/create')); ?>"><i class="fa fa-lg fa-plus"></i></a><a class="btn btn-info btn-flat" href="<?php echo e(url('contests')); ?>"><i class="fa fa-lg fa-refresh"></i></a><a class="btn btn-warning btn-flat" href="#"><i class="fa fa-lg fa-trash"></i></a></div>
        </div>
  <div class="row">
          <div class="col-md-12">
            <div class="card">
              <div class="card-body">
                <table class="table table-hover table-bordered" id="sampleTable">
                  <thead>
                    <tr>
                      <th>Id</th>
					    <th>Name</th>
                      <th>Description</th>
					  <th>Created Date</th>
					  <th>Update Date</th>
                     <th><font color="red">Action</font></th>
                    </tr>
                  </thead>
                  <tbody>
  <?php $__empty_1 = true; $__currentLoopData = $contests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
  
    <tr>
                      <td><?php echo e($contest->id); ?></td>
					  <td><?php echo e($contest->name); ?></td>
                      <td><?php echo e($contest->description); ?></td>
						<td><?php echo e($contest->created_at); ?></td>
					   <td><?php echo e($contest->updated_at); ?></td>
                 
                      <td>
					  <a href="<?php echo e(url('/contests', $contest->id)); ?>" class="btn btn-default"> View</a>
					<a  href="<?php echo e(route('contests.edit', $contest->id)); ?>" class="btn btn-success" > Edit </a>

					<?php echo Form::open(array('method' => 'delete', 'action' => array('ContestController@destroy',  $contest->id))); ?>

					<?php echo Form::hidden('id', $contest->id); ?>

					<?php echo Form::submit('Delete', ['class' => 'btn btn-danger ']); ?>

					<?php echo Form::close(); ?>

				</td>
				  </tr>

   
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
   <p>There are no contests to display!</p>
  <?php endif; ?>
  </tbody>
                </table>
				
              </div>
            </div>
          </div>
        </div>
   
   
   
      </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>