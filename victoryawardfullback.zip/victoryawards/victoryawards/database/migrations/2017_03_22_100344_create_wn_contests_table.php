<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateWnContestsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
		
        Schema::create('wn_contests', function (Blueprint $table) {
            $table->increments('id');
			$table->string('name');
			$table->string('description');
			$table->string('category');
			$table->string('start_date');
			$table->string('end_date');
			$table->string('voting_start_date');
			$table->string('voting_end_date');
			$table->enum('payment_type', ['0', '1']);
			$table->longText('image');
			$table->enum('status', ['0', '1']);
            $table->timestamps();
        });
		
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('wn_contests');
    }
}
