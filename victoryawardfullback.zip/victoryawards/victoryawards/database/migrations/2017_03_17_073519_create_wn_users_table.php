<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateWnUsersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('wn_users', function (Blueprint $table) {
            $table->increments('user_id');
            $table->integer('role_id');
            $table->string('firstname');
            $table->string('lastname');
            $table->string('username');
            $table->string('email');
            $table->string('password');
            $table->string('companyname');
            $table->integer('country_id');
            $table->string('description');
            $table->string('ip');
            $table->date('update_date');
            $table->enum('status', ['0', '1']);
            $table->timestamps('create_date');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('wn_users');
    }
}
