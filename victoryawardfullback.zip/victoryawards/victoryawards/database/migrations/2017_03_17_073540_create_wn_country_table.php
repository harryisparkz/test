<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateWnCountryTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('wn_country', function (Blueprint $table) {
            $table->increments('country_id');
            $table->string('name');
            $table->char('iso_code_2', 2);
            $table->char('iso_code_3', 3);
            $table->char('iso_code_num_3', 3);
            $table->integer('continent_code');
            $table->enum('status', ['0', '1']);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
       Schema::dropIfExists('wn_country');
    }
}
