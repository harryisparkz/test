$(function(){

/* validation for admin add question page */
$("#questionForm").validate({
	   rules: {
                "description": {
                    required: true,
                },
                 "questiontype_id": {
                    required: true,
                },
                "word_limit": {
                    required: true,
                },
                "is_muliple": {
                    required: true,
                },
                "marks": {
                    required: true,
                },
                 "answer_type": {
                    required: true,
                },
                 "status": {
                    required: true,
                },
            },
            messages: {
                "description": {
                    required: "Please, enter Discription"
                },
                 "questiontype_id": {
                    required: "Please, enter a question type"
                },
                "word_limit": {
                    required: "Please, enter word limit"
                },
                "is_muliple": {
                    required: "Please select a value",
                },
                "marks": {
                    required: "Please, enter marks"
                },
                "answer_type": {
                    required: "Please, enter a Answer-Type"
                },
                "status": {
                    required: "Please, select a status"
                },
            },
            submitHandler: function (form) { 
                //alert('valid form submitted'); 
                $("#questionForm").submit();
                return false; 
            }
        });
/*------------------- End ---------------------*/
/*------------------- Contest From Start ---------------------*/
  $('#start_date').datepicker({ 
      	format: "dd-mm-yyyy",
      	autoclose: true,
      	todayHighlight: true
      });
	  $('#end_date').datepicker({
      	format: "dd-mm-yyyy",
      	autoclose: true,
      	todayHighlight: true
      });
	  $('#voting_start_date').datepicker({
      	format: "dd-mm-yyyy",
      	autoclose: true,
      	todayHighlight: true
      });
	    $('#voting_end_date').datepicker({
      	format: "dd-mm-yyyy",
      	autoclose: true,
      	todayHighlight: true
      });
/*------------------- Contest Form Start ---------------------*/

/* ---- Admin Add user form validation --------- */

      $("#adminAddUser").validate({
            rules: {
                "firstname": {
                    required: true,
                },
                 "lastname": {
                    required: true,
                },
                "username": {
                    required: true,
                },
                "email": {
                    required: true,
                    email: true
                },
                "password": {
                    required: true,
                     minlength: 6
                },
                 "company": {
                    required: true,
                },
                "country": {
                    required: true,
                },
                "discription": {
                    required: true,
                },
            },
            messages: {
                "firstname": {
                    required: "Please, enter a First-name"
                },
                 "lastname": {
                    required: "Please, enter a Last-name"
                },
                "username": {
                    required: "Please, enter a User-Name"
                },
                "email": {
                    required: "Please, enter an email",
                    email: "Email is invalid"
                },
                "password": {
                    required: "Please, enter Password"
                },
                "company": {
                    required: "Please, enter Company Name"
                },
                "country": {
                    required: "Please, Select a country"
                },
                "discription": {
                    required: "Please, Enter Discription"
                },
            },
            submitHandler: function (form) { 
                //alert('valid form submitted'); 
                $("#adminAddUser").submit();
                return false; 
            }
        });

/* ------------ End ---------------------*/
/* ---- Admin Add Contest form validation --------- */
$("#contestForm").validate({
            rules: {
                "name": {
                    required: true,
                },
                 "description": {
                    required: true,
                },
                "start_date": {
                    required: true,
                },
                "end_date": {
                    required: true,
                },
                "voting_start_date": {
                    required: true,
                },
                 "voting_end_date": {
                    required: true,
                },
                "category[]": {
                    required: true,
                },
                "payment_type": {
                    required: true,
                },
                "image": {
                    required: true,
                },
                "status": {
                    required: true,
                },
            },
            messages: {
                "name": {
                    required: "Please, enter name"
                },
                 "description": {
                    required: "Please, enter discription"
                },
                "start_date": {
                    required: "Please, enter a start date"
                },
                "end_date": {
                    required: "Please, enter end date",
                },
                "voting_start_date": {
                    required: "Please, enter a voting start date"
                },
                "voting_end_date": {
                    required: "Please, enter a voting end date"
                },
                "category[]": {
                    required: "Please, Select a category"
                },
                "payment_type": {
                    required: "Please, select a payment type"
                }, 
                "image": {
                    required: "Please, Upload a image"
                },
                 "status": {
                    required: "Please, select status"
                },
            },
            submitHandler: function (form) { 
                //alert('valid form submitted'); 
                $("#contestForm").submit();
                return false; 
            }
        });

/* ------------ End ---------------------*/  	  
/* ---- Admin Add Category form validation --------- */
$("#categoryForm").validate({
            rules: {
                "name": {
                    required: true,
                },
                 "description": {
                    required: true,
                },
                "priority": {
                    required: true,
                },
                "status": {
                    required: true,
                },
            },
            messages: {
                "name": {
                    required: "Please, enter name"
                },
                 "description": {
                    required: "Please, enter discription"
                },
                "priority": {
                    required: "Please, set priority"
                },
                "status": {
                    required: "Please, select status"
                },
            },
            submitHandler: function (form) { 
                //alert('valid form submitted'); 
                $("#categoryForm").submit();
                return false; 
            }
        });
/* ------------ End ---------------------*/
});
