@extends('layouts.app')

@section('content')
<div class="content-wrapper">
        <div class="page-title">
          <div>
            <h1><i class="fa fa-edit"></i> Form Componants</h1>
            <p>Bootstrap default form componants</p>
          </div>
          <div>
            <ul class="breadcrumb">
              <li><i class="fa fa-home fa-lg"></i></li>
              <li>Forms</li>
              <li><a href="#">Form Componants</a></li>
            </ul>
          </div>
        </div>
        <div class="row">
          <div class="col-md-12">
            <div class="card">
              <div class="row">
                <div class="col-lg-10">
                  <div class="well bs-component">
                    <form class="form-horizontal">
                      <fieldset>
                        <legend>Legend</legend>
                        <div class="form-group">
                          <label class="col-lg-2 control-label" for="inputEmail">Email</label>
                          <div class="col-lg-10">
                            <input class="form-control" id="inputEmail" type="text" placeholder="Email">
                          </div>
                        </div>
                        <div class="form-group">
                          <label class="col-lg-2 control-label" for="inputPassword">Password</label>
                          <div class="col-lg-10">
                            <input class="form-control" id="inputPassword" type="password" placeholder="Password">
                            <div class="checkbox">
                              <label>
                                <input type="checkbox">Checkbox
                              </label>
                            </div>
                          </div>
                        </div>
                        <div class="form-group">
                          <label class="col-lg-2 control-label" for="textArea">Textarea</label>
                          <div class="col-lg-10">
                            <textarea class="form-control" id="textArea" rows="3"></textarea><span class="help-block">A longer block of help text that breaks onto a new line and may extend beyond one line.</span>
                          </div>
                        </div>
                        <div class="form-group">
                          <label class="col-lg-2 control-label">Radios</label>
                          <div class="col-lg-10">
                            <div class="radio">
                              <label>
                                <input id="optionsRadios1" type="radio" name="optionsRadios" value="option1" checked="">Option one is this
                              </label>
                            </div>
                            <div class="radio">
                              <label>
                                <input id="optionsRadios2" type="radio" name="optionsRadios" value="option2">Option two can be something else
                              </label>
                            </div>
                          </div>
                        </div>
                        <div class="form-group">
                          <label class="col-lg-2 control-label" for="select">Selects</label>
                          <div class="col-lg-10">
                            <select class="form-control" id="select">
                              <option>1</option>
                              <option>2</option>
                              <option>3</option>
                              <option>4</option>
                              <option>5</option>
                            </select><br>
                            <select class="form-control" multiple="">
                              <option>1</option>
                              <option>2</option>
                              <option>3</option>
                              <option>4</option>
                              <option>5</option>
                            </select>
                          </div>
                        </div>
                        <div class="form-group">
                          <div class="col-lg-10 col-lg-offset-2">
                            <button class="btn btn-default" type="reset">Cancel</button>
                            <button class="btn btn-primary" type="submit">Submit</button>
                          </div>
                        </div>
                      </fieldset>
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
  @endsection