@extends('layouts.app')

@section('content')
<div class="content-wrapper">
        <div class="page-title">
          <div>
            <h1><i class="fa fa-edit"></i>Show Category</h1>
            <p>Show Category</p>
          </div>
          <div>
            <ul class="breadcrumb">
              <li><i class="fa fa-home fa-lg"></i></li>
              <li>Category Section</li>
              <li><a href="#">Show Category</a></li>
            </ul>
          </div>
        </div>
        <div class="row">
          <div class="col-md-12">
            <div class="card">
              <div class="row">
                <div class="col-lg-10">
                  <div class="well bs-component">
				  {!! Form::open(['class'=>'form-horizontal']) !!}
				   <fieldset>
					<legend>Category</legend>
				  {{ csrf_field() }}
				  	<div class='form-group'>
				{!! Form::label('name', 'Name:',['class' => 'col-lg-2 control-label']) !!}
				<div class="col-lg-10">
				{{ $categories->name }}
				</div>
			</div>
			<div class='form-group'>
				{!! Form::label('description', 'Description:',['class' => 'col-lg-2 control-label']) !!}
				<div class="col-lg-10">
				{{ $categories->description }}
				</div>
			</div>
		
			<div class='form-group'>
				{!! Form::label('priority', 'Priority:',['class' => 'col-lg-2 control-label']) !!}
				<div class="col-lg-10">
				{{ $categories->priority }}
				</div>
			</div> 
				  </fieldset>
				  
				    {!! Form::close() !!}
					
		</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
	  
@stop
