@extends('layouts.app')

@section('content')

<div class="content-wrapper">
        <div class="page-title">
          <div>
            <h1><i class="fa fa-edit"></i>Edit Category</h1>
            <p>Update Category</p>
          </div>
          <div>
            <ul class="breadcrumb">
              <li><i class="fa fa-home fa-lg"></i></li>
              <li>Category Section</li>
              <li><a href="#">Edit Category</a></li>
            </ul>
          </div>
        </div>
        <div class="row">
          <div class="col-md-12">
            <div class="card">
              <div class="row">
                <div class="col-lg-10">
                  <div class="well bs-component">
		
		{!! Form::model($categories, ['method' => 'PATCH', 'action' => ['CategoryController@update',$categories->id],'class'=>'form-horizontal', 'id' =>'categoryForm']) !!}
			@include('categories.form', ['submitButtonText' => 'Edit Category'])
		{!! Form::close() !!}
				</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
@stop