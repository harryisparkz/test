 <fieldset>
 <legend>Category</legend>
{{ csrf_field() }}
			<div class='form-group'>
				{!! Form::label('name', 'Name:',['class' => 'col-lg-2 control-label']) !!}
				<div class="col-lg-10">
				{!! Form::text('name', null, ['class' => 'form-control', 'id' => 'name']) !!}
				@if ($errors->has('name'))
					<p style="color:red;">
					{!!$errors->first('name')!!}
					</p>
				@endif
				</div>
			</div>
			<div class='form-group'>
				{!! Form::label('description', 'Description:',['class' => 'col-lg-2 control-label']) !!}
				<div class="col-lg-10">
				{!! Form::textarea('description', null, ['class' => 'form-control', 'id' => 'description']) !!}
				@if ($errors->has('description'))
					<p style="color:red;">
					{!!$errors->first('description')!!}
					</p>
				@endif
				</div>
			</div>
			
	
		<div class='form-group'>
			{!! Form::label('priority', 'Priority:',['class' => 'col-lg-2 control-label']) !!}
				<div class="col-lg-10">
			{!! Form::text('priority', null, ['class' => 'form-control', 'id' => 'priority']) !!}
				@if ($errors->has('priority'))
					<p style="color:red;">
					{!!$errors->first('priority')!!}
					</p>
				@endif
				</div>
		</div>
	
		<div class='form-group'>
			{!! Form::label('status', 'Status:',['class' => 'col-lg-2 control-label']) !!}
				<div class="col-lg-10">
			{!! Form::select('status',  ['1' => 'Enable', '0' => 'Disable'],null, ['class' => 'form-control', 'id' => 'status']) !!}
				@if ($errors->has('status'))
					<p style="color:red;">
					{!!$errors->first('status')!!}
					</p>
				@endif
				</div>
		</div>
		
		
		 


<script>
var input, autocomplete;

function initialize() {

	input = document.getElementById('location');
	autocomplete = new google.maps.places.Autocomplete(input);
}

google.maps.event.addDomListener(window, 'load', initialize);

function createCandidate(a, b, c){
	var name = document.getElementById("name").value;
	var email = document.getElementById("email").value;
	var phone = document.getElementById("phone").value;

	// var place = autocomplete.getPlace();
	// console.log(place);

	// var latitude = place.geometry.location.lat();
	// var longitude = place.geometry.location.lng();
	// console.log(latitude, longitude);



}

function editCandidate(){
	console.log('edit form submitted!');
}
</script>

<div class='form-group'>
    <div class="col-lg-10 col-lg-offset-2">
	 <a href="{{ url('categories') }}" class="btn btn-default" >Cancel</a>
	{!! Form::submit($submitButtonText, ['class' => 'btn btn-primary']) !!}
	</div>
</div>
  </fieldset>