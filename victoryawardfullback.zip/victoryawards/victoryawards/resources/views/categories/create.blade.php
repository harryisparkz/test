@extends('layouts.app')

@section('content')


<div class="content-wrapper">
        <div class="page-title">
          <div>
            <h1><i class="fa fa-edit"></i>Add Category</h1>
            <p>Add New Category</p>
          </div>
          <div>
            <ul class="breadcrumb">
              <li><i class="fa fa-home fa-lg"></i></li>
              <li>Category Section</li>
              <li><a href="#">Add Category</a></li>
            </ul>
          </div>
        </div>
        <div class="row">
          <div class="col-md-12">
            <div class="card">
              <div class="row">
                <div class="col-lg-10">
                  <div class="well bs-component">
				  
{!! Form::open(['action' => 'CategoryController@store','class'=>'form-horizontal', 'id' =>'categoryForm']) !!}
   @include('categories.form', ['submitButtonText' => 'Add Category'])
  {!! Form::close() !!}
	
	
				</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
@stop


