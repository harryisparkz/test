@extends('layouts.app')

@section('content')
<div class="content-wrapper">
        <div class="page-title">
          <div>
            <h1>Data Table</h1>
            <ul class="breadcrumb side">
              <li><i class="fa fa-home fa-lg"></i></li>
              <li>Tables</li>
              <li class="active"><a href="#">Data Table</a></li>
            </ul>
          </div>
          <div><a class="btn btn-primary btn-flat" href="{{ url('questions/create') }}"><i class="fa fa-lg fa-plus"></i></a><a class="btn btn-info btn-flat" href="{{ url('questions') }}"><i class="fa fa-lg fa-refresh"></i></a><a class="btn btn-warning btn-flat" href="#"><i class="fa fa-lg fa-trash"></i></a></div>
        </div>
  <div class="row">
          <div class="col-md-12">
            <div class="card">
              <div class="card-body">
                <table class="table table-hover table-bordered" id="sampleTable">
                  <thead>
                    <tr>
                      <th>Id</th>
                      <th>Description</th>
                      <th>Question Type</th>
					  <th>Created Date</th>
					  <th>Update Date</th>
                   
                      <th><font color="red">Action</font></th>
                    </tr>
                  </thead>
                  <tbody>
  @forelse($questions as $question)
  
    <tr>
                      <td>{{ $question->id }}</td>
                      <td>{{ $question->description }}</td>
                      <td>{{ $question->questiontype_id }}</td>
                      <td>{{ $question->created_at }}</td>
					   <td>{{ $question->updated_at }}</td>
                 
                      <td>
					  <a href="{{ url('/questions', $question->id) }}" class="btn btn-default"> View</a>
					<a  href="{{ route('questions.edit', $question->id) }}" class="btn btn-success" > Edit </a>

					{!! Form::open(array('method' => 'delete', 'action' => array('QuestionController@destroy',  $question->id))) !!}
					{!! Form::hidden('id', $question->id) !!}
					{!! Form::submit('Delete', ['class' => 'btn btn-danger ']) !!}
					{!! Form::close() !!}
				</td>
				  </tr>

   
  @empty
   <p>There are no questions to display!</p>
  @endforelse
  </tbody>
                </table>
				
              </div>
            </div>
          </div>
        </div>
   
   
   
      </div>
@stop