 <fieldset id="fieldset_id">
 <legend>Question</legend>
{{ csrf_field() }}
			<div class='form-group'>
				{!! Form::label('description', 'Description:',['class' => 'col-lg-2 control-label']) !!}
				<div class="col-lg-10">
				{!! Form::textarea('description', null, ['class' => 'form-control', 'id' => 'description']) !!}
				@if ($errors->has('description'))
					<p style="color:red;">
					{!!$errors->first('description')!!}
					</p>
				@endif
				</div>
			</div>
		<!-- 	<div class='form-group'>
				{!! Form::label('questiontype_id', 'Question Type:',['class' => 'col-lg-2 control-label']) !!}
				<div class="col-lg-10">
				{!! Form::text('questiontype_id', null, ['class' => 'form-control', 'id' => 'questiontype_id']) !!}
				@if ($errors->has('questiontype_id'))
					<p style="color:red;">
					{!!$errors->first('questiontype_id')!!}
					</p>
				@endif
				</div>
			</div>
 -->
		    <div class='form-group'>
			{!! Form::label('questiontype_id', 'Question Type:',['class' => 'col-lg-2 control-label']) !!}
				<div class="col-lg-10">
			{!! Form::select('questiontype_id',  ['1' => 'Text', '2' => 'Radio', '3' => 'Checkbox', '4' => 'Select', '5' => 'Textarea', '7' => 'number', '8' => 'Email', '9' => 'Url', '10' => 'Date', '11' => 'File', '12' => 'Button', '13' => 'Tel', '14' => 'Hidden', '15' => 'Image'],null, ['class' => 'form-control', 'id' => 'questiontype_id']) !!}
				@if ($errors->has('questiontype_id'))
					<p style="color:red;">
					{!!$errors->first('questiontype_id')!!}
					</p>
				@endif
				</div>
		    </div>

	
		<div class='form-group'>
			{!! Form::label('word_limit', 'Word Limit:',['class' => 'col-lg-2 control-label']) !!}
				<div class="col-lg-10">
			{!! Form::text('word_limit', null, ['class' => 'form-control', 'id' => 'word_limit']) !!}
				@if ($errors->has('word_limit'))
					<p style="color:red;">
					{!!$errors->first('word_limit')!!}
					</p>
				@endif
				</div>
		</div>
		<div class='form-group'>
			{!! Form::label('is_muliple', 'Is Muliple:',['class' => 'col-lg-2 control-label']) !!}
				<div class="col-lg-10">
			{!! Form::select('is_muliple',['0' => 'No', '1' => 'Yes'], null, ['class' => 'form-control', 'id' => 'is_muliple']) !!}
				@if ($errors->has('is_muliple'))
					<p style="color:red;">
					{!!$errors->first('is_muliple')!!}
					</p>
				@endif
				</div>
		</div>
		<div class='form-group'>
			{!! Form::label('marks', 'Marks:',['class' => 'col-lg-2 control-label']) !!}
				<div class="col-lg-10">
			{!! Form::text('marks', null, ['class' => 'form-control', 'id' => 'marks']) !!}
				@if ($errors->has('marks'))
					<p style="color:red;">
					{!!$errors->first('marks')!!}
					</p>
				@endif
				</div>
		</div>
		<div class='form-group'>
			{!! Form::label('answer_type', 'Answer Type:',['class' => 'col-lg-2 control-label']) !!}
				<div class="col-lg-10">
			{!! Form::text('answer_type', null, ['class' => 'form-control', 'id' => 'answer_type']) !!}
				@if ($errors->has('answer_type'))
					<p style="color:red;">
					{!!$errors->first('answer_type')!!}
					</p>
				@endif
				</div>
		</div>
		<div class='form-group'>
			{!! Form::label('status', 'Status:',['class' => 'col-lg-2 control-label']) !!}
				<div class="col-lg-10">
			{!! Form::select('status',  ['1' => 'Enable', '0' => 'Disable'],null, ['class' => 'form-control', 'id' => 'status']) !!}
				@if ($errors->has('status'))
					<p style="color:red;">
					{!!$errors->first('status')!!}
					</p>
				@endif
				</div>
		</div>
		
		
		 


<script>
var input, autocomplete;

function initialize() {

	input = document.getElementById('location');
	autocomplete = new google.maps.places.Autocomplete(input);
}

google.maps.event.addDomListener(window, 'load', initialize);

function createCandidate(a, b, c){
	var name = document.getElementById("name").value;
	var email = document.getElementById("email").value;
	var phone = document.getElementById("phone").value;

	// var place = autocomplete.getPlace();
	// console.log(place);

	// var latitude = place.geometry.location.lat();
	// var longitude = place.geometry.location.lng();
	// console.log(latitude, longitude);



}

function editCandidate(){
	console.log('edit form submitted!');
}
</script>

<div class='form-group'>
    <div class="col-lg-10 col-lg-offset-2">
	 <button class="btn btn-default" type="reset">Cancel</button>
	{!! Form::submit($submitButtonText, ['class' => 'btn btn-primary']) !!}
	</div>
</div>
  </fieldset>
