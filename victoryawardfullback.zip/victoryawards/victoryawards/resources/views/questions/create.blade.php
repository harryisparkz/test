@extends('layouts.app')

@section('content')


<div class="content-wrapper">
        <div class="page-title">
          <div>
            <h1><i class="fa fa-edit"></i>Add Question</h1>
            <p>Add New Question</p>
          </div>
          <div>
            <ul class="breadcrumb">
              <li><i class="fa fa-home fa-lg"></i></li>
              <li>Question Section</li>
              <li><a href="#">Add Question</a></li>
            </ul>
          </div>
        </div>
        <div class="row">
          <div class="col-md-12">
            <div class="card">
              <div class="row">
                <div class="col-lg-10">
                  <div class="well bs-component">
				  
{!! Form::open(['action' => 'QuestionController@store','class'=>'form-horizontal', 'id'=> 'questionForm']) !!}
   @include('questions.form', ['submitButtonText' => 'Add Question'])
  {!! Form::close() !!}
	
	
				</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
@stop


