@extends('layouts.app')

@section('content')

<div class="content-wrapper">
        <div class="page-title">
          <div>
            <h1><i class="fa fa-edit"></i>Edit Question</h1>
            <p>Update Question</p>
          </div>
          <div>
            <ul class="breadcrumb">
              <li><i class="fa fa-home fa-lg"></i></li>
              <li>Question Section</li>
              <li><a href="#">Edit Question</a></li>
            </ul>
          </div>
        </div>
        <div class="row">
          <div class="col-md-12">
            <div class="card">
              <div class="row">
                <div class="col-lg-10">
                  <div class="well bs-component">
		
		{!! Form::model($question, ['method' => 'PATCH', 'action' => ['QuestionController@update',$question->id],'class'=>'form-horizontal', 'id'=> 'questionForm']) !!}
			@include('questions.form', ['submitButtonText' => 'Edit Question'])
		{!! Form::close() !!}
				</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
@stop
