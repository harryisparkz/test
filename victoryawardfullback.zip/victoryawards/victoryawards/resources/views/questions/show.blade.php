@extends('layouts.app')

@section('content')
<div class="content-wrapper">
        <div class="page-title">
          <div>
            <h1><i class="fa fa-edit"></i>Show Question</h1>
            <p>Show Question</p>
          </div>
          <div>
            <ul class="breadcrumb">
              <li><i class="fa fa-home fa-lg"></i></li>
              <li>Question Section</li>
              <li><a href="#">Show Question</a></li>
            </ul>
          </div>
        </div>
        <div class="row">
          <div class="col-md-12">
            <div class="card">
              <div class="row">
                <div class="col-lg-10">
                  <div class="well bs-component">
				  {!! Form::open(['class'=>'form-horizontal']) !!}
				   <fieldset>
					<legend>Question</legend>
				  {{ csrf_field() }}
			<div class='form-group'>
				{!! Form::label('description', 'Description:',['class' => 'col-lg-2 control-label']) !!}
				<div class="col-lg-10">
				{{ $question->description }}
				</div>
			</div>
			<div class='form-group'>
				{!! Form::label('questiontype_id', 'Question Type:',['class' => 'col-lg-2 control-label']) !!}
				<div class="col-lg-10">
				{{ $question->questiontype_id }}
				</div>
			</div> 
			<div class='form-group'>
				{!! Form::label('word_limit', 'Word Limit:',['class' => 'col-lg-2 control-label']) !!}
				<div class="col-lg-10">
				{{ $question->word_limit }}
				</div>
			</div> 
				  </fieldset>
				  
				    {!! Form::close() !!}
					
		</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
	  
@stop
