@extends('layouts.app')

@section('content')

<div class="content-wrapper">
        <div class="page-title">
          <div>
            <h1><i class="fa fa-edit"></i>Edit Contest</h1>
            <p>Update Contest</p>
          </div>
          <div>
            <ul class="breadcrumb">
              <li><i class="fa fa-home fa-lg"></i></li>
              <li>Contest Section</li>
              <li><a href="#">Edit Contest</a></li>
            </ul>
          </div>
        </div>
        <div class="row">
          <div class="col-md-12">
            <div class="card">
              <div class="row">
                <div class="col-lg-10">
                  <div class="well bs-component">
		
		{!! Form::model($contest, ['method' => 'PATCH', 'action' => ['ContestController@update',$contest->id],'class'=>'form-horizontal','id' => 'contestForm','files'=>true]) !!}
			@include('contests.form', ['submitButtonText' => 'Edit Contest'])
		{!! Form::close() !!}
				</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
@stop