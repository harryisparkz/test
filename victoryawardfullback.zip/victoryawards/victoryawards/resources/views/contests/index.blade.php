@extends('layouts.app')

@section('content')
<div class="content-wrapper">
        <div class="page-title">
          <div>
            <h1>Contests Section</h1>
            <ul class="breadcrumb side">
              <li><i class="fa fa-home fa-lg"></i></li>
              <li>Contests</li>
              <li class="active"><a href="#">Contests Section</a></li>
            </ul>
          </div>
          <div><a class="btn btn-primary btn-flat" href="{{ url('contests/create') }}"><i class="fa fa-lg fa-plus"></i></a><a class="btn btn-info btn-flat" href="{{ url('contests') }}"><i class="fa fa-lg fa-refresh"></i></a><a class="btn btn-warning btn-flat" href="#"><i class="fa fa-lg fa-trash"></i></a></div>
        </div>
  <div class="row">
          <div class="col-md-12">
            <div class="card">
              <div class="card-body">
                <table class="table table-hover table-bordered" id="sampleTable">
                  <thead>
                    <tr>
                      <th>Id</th>
					    <th>Name</th>
                      <th>Description</th>
					  <th>Created Date</th>
					  <th>Update Date</th>
                     <th><font color="red">Action</font></th>
                    </tr>
                  </thead>
                  <tbody>
  @forelse($contests as $contest)
  
    <tr>
                      <td>{{ $contest->id }}</td>
					  <td>{{ $contest->name }}</td>
                      <td>{{ $contest->description }}</td>
						<td>{{ $contest->created_at }}</td>
					   <td>{{ $contest->updated_at }}</td>
                 
                      <td>
					  <a href="{{ url('/contests', $contest->id) }}" class="btn btn-default"> View</a>
					<a  href="{{ route('contests.edit', $contest->id) }}" class="btn btn-success" > Edit </a>

					{!! Form::open(array('method' => 'delete', 'action' => array('ContestController@destroy',  $contest->id))) !!}
					{!! Form::hidden('id', $contest->id) !!}
					{!! Form::submit('Delete', ['class' => 'btn btn-danger ']) !!}
					{!! Form::close() !!}
				</td>
				  </tr>

   
  @empty
   <p>There are no contests to display!</p>
  @endforelse
  </tbody>
                </table>
				
              </div>
            </div>
          </div>
        </div>
   
   
   
      </div>
@stop