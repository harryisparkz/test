 <fieldset>
 <legend>Contest</legend>
{{ csrf_field() }}
		<div class='form-group'>
				{!! Form::label('name', 'Name:',['class' => 'col-lg-2 control-label']) !!}
				<div class="col-lg-10">
				{!! Form::text('name', null, ['class' => 'form-control', 'id' => 'name']) !!}
				@if ($errors->has('name'))
					<p style="color:red;">
					{!!$errors->first('name')!!}
					</p>
				@endif
				</div>
			</div>
			<div class='form-group'>
				{!! Form::label('description', 'Description:',['class' => 'col-lg-2 control-label']) !!}
				<div class="col-lg-10">
				{!! Form::textarea('description', null, ['class' => 'form-control', 'id' => 'description']) !!}
				@if ($errors->has('description'))
					<p style="color:red;">
					{!!$errors->first('description')!!}
					</p>
				@endif
				</div>
			</div>
			<div class='form-group'>
				{!! Form::label('start_date', 'Start Date:',['class' => 'col-lg-2 control-label']) !!}
				<div class="col-lg-10">
				{!! Form::text('start_date',null, ['class' => 'form-control', 'id' => 'start_date']) !!}
				@if ($errors->has('start_date'))
					<p style="color:red;">
					{!!$errors->first('start_date')!!}
					</p>
				@endif
				</div>
			</div>
			<div class='form-group'>
				{!! Form::label('end_date', 'End Date:',['class' => 'col-lg-2 control-label']) !!}
				<div class="col-lg-10">
				{!! Form::text('end_date',null, ['class' => 'form-control', 'id' => 'end_date']) !!}
				@if ($errors->has('end_date'))
					<p style="color:red;">
					{!!$errors->first('end_date')!!}
					</p>
				@endif
				</div>
			</div>
			<div class='form-group'>
				{!! Form::label('voting_start_date', 'Voting Start Date:',['class' => 'col-lg-2 control-label']) !!}
				<div class="col-lg-10">
				{!! Form::text('voting_start_date',null, ['class' => 'form-control', 'id' => 'voting_start_date']) !!}
				@if ($errors->has('voting_start_date'))
					<p style="color:red;">
					{!!$errors->first('voting_start_date')!!}
					</p>
				@endif
				</div>
			</div>
			<div class='form-group'>
				{!! Form::label('voting_end_date', 'Voting End Date:',['class' => 'col-lg-2 control-label']) !!}
				<div class="col-lg-10">
				{!! Form::text('voting_end_date',null, ['class' => 'form-control', 'id' => 'voting_end_date']) !!}
				@if ($errors->has('voting_end_date'))
					<p style="color:red;">
					{!!$errors->first('voting_end_date')!!}
					</p>
				@endif
				</div>
			</div>
			
			
			
			<div class='form-group'>
				{!! Form::label('category', 'Category Select:',['class' => 'col-lg-2 control-label']) !!}
				<div class="col-lg-10">
				@if(array_key_exists("selected",$categories) )
				{{ Form::select('category[]', $categories['all_categ']['categories'], Request::old('category') ? Request::old('category') : $categories['selected'], array('multiple' => true)) }}
				@else
				{!! Form::select('category[]', $categories, null, ['multiple' => true], ['class' => 'form-control', 'id' => 'category']) !!}
				@endif
				@if ($errors->has('category'))
					<p style="color:red;">
					{!!$errors->first('category')!!}
					</p>
				@endif
				</div>
			</div>
		
		<div class='form-group'>
			{!! Form::label('payment_type', 'Payment Type:',['class' => 'col-lg-2 control-label']) !!}
				<div class="col-lg-10">
			{!! Form::select('payment_type',  ['0' => 'Free', '1' => 'Paid'],null, ['class' => 'form-control', 'id' => 'payment_type']) !!}
				@if ($errors->has('payment_type'))
					<p style="color:red;">
					{!!$errors->first('payment_type')!!}
					</p>
				@endif
				</div>
		</div>
		<div class='form-group'>
			{!! Form::label('image', 'Image:',['class' => 'col-lg-2 control-label']) !!}
				<div class="col-lg-10">
			{!! Form::file('image',  null,['class' => 'form-control', 'id' => 'image']) !!}
			{{ Form::hidden('selected_image',isset( $contest['image']) ?  $contest['image'] : 'Default.jpg') }}
            <img src="{{ url('/public/images') }}/{{ isset( $contest['image']) ?  $contest['image'] : 'Default.jpg' }} " height="100px" width="100px" alt="default-img">
				
				@if ($errors->has('image'))
					<p style="color:red;">
					{!!$errors->first('image')!!}
					</p>
				@endif
				</div>
		</div>
			
		<div class='form-group'>
			{!! Form::label('status', 'Status:',['class' => 'col-lg-2 control-label']) !!}
				<div class="col-lg-10">
			{!! Form::select('status',  ['1' => 'Published', '0' => 'Not-Published'],null, ['class' => 'form-control', 'id' => 'status']) !!}
				@if ($errors->has('status'))
					<p style="color:red;">
					{!!$errors->first('status')!!}
					</p>
				@endif
				</div>
		</div>
		
		
		 


<script>
var input, autocomplete;

function initialize() {

	input = document.getElementById('location');
	autocomplete = new google.maps.places.Autocomplete(input);
}

google.maps.event.addDomListener(window, 'load', initialize);

function createCandidate(a, b, c){
	var name = document.getElementById("name").value;
	var email = document.getElementById("email").value;
	var phone = document.getElementById("phone").value;

	// var place = autocomplete.getPlace();
	// console.log(place);

	// var latitude = place.geometry.location.lat();
	// var longitude = place.geometry.location.lng();
	// console.log(latitude, longitude);



}

function editCandidate(){
	console.log('edit form submitted!');
}
</script>

<div class='form-group'>
    <div class="col-lg-10 col-lg-offset-2">
	 <button class="btn btn-default" type="reset">Cancel</button>
	{!! Form::submit($submitButtonText, ['class' => 'btn btn-primary']) !!}
	</div>
</div>
  </fieldset>