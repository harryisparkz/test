@extends('layouts.app')

@section('content')
<div class="content-wrapper">
        <div class="page-title">
          <div>
            <h1><i class="fa fa-th-list"></i> User Details</h1>
            <p> Table for display user details</p>
          </div>
          <div>
            <ul class="breadcrumb">
              <li><i class="fa fa-home fa-lg"></i></li>
              <li>Tables</li>
              <li class="active"><a href="#">Simple Tables</a></li>
            </ul>
          </div>
        </div>
       <div class="clearfix"></div>
          <div class="col-md-12">
            <div class="card">
              <h3 class="card-title">User Details</h3>
              <div class="table-responsive">
                <table class="table">
                 <tbody>
                  @if(!empty($value))
                    <tr><td><strong>First Name</strong></td><td>{{ $value[0]['firstname']}}</td></tr>
                      <tr><td><strong>Last Name</strong></td><td>{{ $value[0]['lastname']}}</td></tr>
                      <tr><td><strong>Username</strong></td><td>{{ $value[0]['username']}}</td></tr>
                      <tr><td><strong>Email</strong></td><td>{{ $value[0]['email']}}</td></tr>
                      <tr><td><strong>Company Name</strong></td><td>{{ $value[0]['companyname']}}</td></tr>
                      <tr><td><strong>Discription</strong></td><td>{{ $value[0]['description']}}</td></tr>
                      <tr><td><strong>Country</strong></td><td>{{ $value[0]['countries_name']}}</td></tr>
                      <tr><td><strong>Role</strong></td><td>{{ $value[0]['name']}}</td></tr>
                  @else
                  <tr><td><font color="red">No Record Found...!!</font></td></tr>
                  @endif
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    @endsection