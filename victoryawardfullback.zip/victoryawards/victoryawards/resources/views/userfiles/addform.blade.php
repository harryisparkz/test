@extends('layouts.app')

@section('content')
<div class="content-wrapper">
        <div class="page-title">
          <div>
            <h1><i class="fa fa-edit"></i> Add User Form</h1>
            <p>Form component for add new users</p>
          </div>
          <div>
            <ul class="breadcrumb">
              <li><i class="fa fa-home fa-lg"></i></li>
              <li>Forms</li>
              <li><a href="#">User Form</a></li>
            </ul>
          </div>
        </div>
        <div class="row">
          <div class="col-md-12">
            <div class="card">
              <div class="row">
                <div class="col-lg-10">
                  <div class="well bs-component">
                    <form class="form-horizontal" action="{{ url('/addUser') }}" method="POST" id="adminAddUser">
                      {{ csrf_field() }}
                      <fieldset>
                        <legend> Add Details</legend>
                        <div class="form-group">
                          <label class="col-lg-2 control-label" for="fname">First Name</label>
                          <div class="col-lg-10">
                            <input class="form-control" id="fname" type="text" placeholder="First Name" name="firstname">
                             @if ($errors->has('firstname'))<p style="color:red;">{!!$errors->first('firstname')!!}</p>@endif
                          </div>
                        </div>
                        <div class="form-group">
                          <label class="col-lg-2 control-label" for="fname">Last Name</label>
                          <div class="col-lg-10">
                            <input class="form-control" id="lname" type="text" placeholder="Last Name" name="lastname">
                             @if ($errors->has('lastname'))<p style="color:red;">{!!$errors->first('lastname')!!}</p>@endif
                          </div>
                        </div>
                        <div class="form-group">
                          <label class="col-lg-2 control-label" for="user-name">User Name</label>
                          <div class="col-lg-10">
                            <input class="form-control" id="username" type="text" placeholder="User-Name" name="username">
                             @if ($errors->has('username'))<p style="color:red;">{!!$errors->first('username')!!}</p>@endif
                          </div>
                        </div>
                        <div class="form-group">
                          <label class="col-lg-2 control-label" for="inputEmail">Email</label>
                          <div class="col-lg-10">
                            <input class="form-control" id="inputEmail" type="email" placeholder="Email" name="email">
                             @if ($errors->has('email'))<p style="color:red;">{!!$errors->first('email')!!}</p>@endif
                          </div>
                        </div>
                        <div class="form-group">
                          <label class="col-lg-2 control-label" for="inputPassword">Password</label>
                          <div class="col-lg-10">
                            <input class="form-control" id="inputPassword" type="password" placeholder="Password" name="password">
                             @if ($errors->has('password'))<p style="color:red;">{!!$errors->first('password')!!}</p>@endif
                          </div>
                        </div>
                        <div class="form-group">
                          <label class="col-lg-2 control-label" for="company-name">Company Name</label>
                          <div class="col-lg-10">
                            <input class="form-control" id="company" type="text" placeholder="Company Name" name="company">
                             @if ($errors->has('company'))<p style="color:red;">{!!$errors->first('company')!!}</p>@endif
                          </div>
                        </div>
                        <div class="form-group">
                          <label class="col-lg-2 control-label" for="select">Country</label>
                          <div class="col-lg-10">
                            <select class="form-control" id="select" name="country">
                              <option value="">Select Country</option>
                                        @if(isset($data) && !empty($data))
                                        @foreach($data as $val)
                                        <option value="{{ $val->country_id }}">{{ $val->countries_name }}</option>
                                        @endForeach
                                        @endIf
                              @if ($errors->has('country'))<p style="color:red;">{!!$errors->first('country')!!}</p>@endif
                            </select>
                           </div>
                        </div>
                        <div class="form-group">
                          <label class="col-lg-2 control-label" for="discription">Discription</label>
                          <div class="col-lg-10">
                            <textarea class="form-control" id="discription" rows="3" name="discription"></textarea>
                             @if ($errors->has('discription'))<p style="color:red;">{!!$errors->first('discription')!!}</p>@endif
                          </div>
                        </div>
                        <div class="form-group">
                          <div class="col-lg-10 col-lg-offset-2">
                            <button class="btn btn-default" type="reset">Cancel</button>
                            <button class="btn btn-primary" type="submit" name="submit" value="submit">Submit</button>
                          </div>
                        </div>
                      </fieldset>
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
  @endsection