@extends('layouts.app')

@section('content')
<div class="content-wrapper">
        <div class="page-title">
          <div>
            <h1>Activated User List</h1>
            <ul class="breadcrumb side">
              <li><i class="fa fa-home fa-lg"></i></li>
              <li>User table</li>
              <li class="active"><a href="#">User List</a></li>
            </ul>
          </div>
          <div><a class="btn btn-primary btn-flat" href="{{url('/addUser')}}"><i class="fa fa-lg fa-plus"></i></a><a class="btn btn-info btn-flat" href="#"><i class="fa fa-lg fa-refresh"></i></a><a class="btn btn-warning btn-flat" href="#"><i class="fa fa-lg fa-trash"></i></a></div>
        </div>
        <div class="row">
          <div class="col-md-12">
            <div class="card">
              <div class="card-body">
                <table class="table table-hover table-bordered" id="sampleTable">
                  <thead>
                    <tr>
                      <th>S.no</th>
                      <th>Firstname</th>
                      <th>Lastname</th>
                      <th>Email</th>
                      <th>Discription</th>
                      <th><font color="red">Action</font></th>
                    </tr>
                  </thead>
                  <tbody>
                    @if(!empty($details))
                    @foreach($details as $key=>$val)  
                    <tr>
                      <td>{{ $key+1 }}</td>
                      <td>{{ $val['firstname'] }}</td>
                      <td>{{ $val['lastname'] }}</td>
                      <td>{{ $val['email'] }}</td>
                      <td>{{ $val['description'] }}</td> 
                      <td><a href="{{ url('/displayUser')}}/{{ $val['user_id'] }}" class="btn btn-default">View</a>@if($val['status'] == 1)<a href="{{ url('/deactivate') }}/{{$val['user_id']}}" class="btn btn-danger">De-Activate</a>@else<a href="{{ url('/activate') }}/{{$val['user_id']}}" class="btn btn-success">Re-Activate</a>@endIf</td>
                    </tr>
                   @endforeach
                   @endif 
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
      @endsection