<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| This file is where you may define all of the routes that are handled
| by your application. Just tell Laravel the URIs it should respond
| to using a Closure or controller method. Build something great!
|
*/

Route::get('/', function () {
    return view('home');
});

Auth::routes();

Route::get('/home', 'HomeController@index');
Route::resource('categories', 'CategoriesController');
Route::resource('operator', 'OperatorsController');
Route::resource('photos', 'PhotosController');
Route::resource('state', 'StatesController');
Route::resource('circle', 'CirclesController');
//Route::resource('plan_information', ['uses' => 'PlansController@plan_information', 'as' => 'information']);

Route::any('/plan_information/saverecord', ['uses' => 'Plan_InformationsController@saverecord', 'as' => 'information']);
Route::any('/plan_information/getrecord', ['uses' => 'Plan_InformationsController@getrecord', 'as' => 'information']);
Route::any('/plan_information/deleterecord', ['uses' => 'Plan_InformationsController@deleterecord', 'as' => 'information']);
Route::any('/plan_information/updaterecord', ['uses' => 'Plan_InformationsController@updaterecord', 'as' => 'information']);

Route::resource('plan_information','Plan_InformationsController');
Route::resource('plan', 'PlansController');
Route::resource('type', 'TypesController');
Route::resource('option', 'OptionsController');
