<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Option extends Model
{
    protected $fillable = ['category_id','option_name','option_type','status']; 
    public function categories()
     {
        return $this->belongsTo('App\Category','category_id');
     }
}
