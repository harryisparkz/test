<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Type;
use App\Category;


class TypesController extends Controller
{
     public function __construct()
     {
        $this->middleware('auth');
     }   
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $types=Type::with('categories')->get();
        return view('types.index',compact('types'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
         $categories = Category::pluck('name','id');
         $categories['']='Select Category';   
         return view('types.create',compact('categories'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
         $this->validate($request, [
        'type_name' => 'required',
        'category_id' => 'required',
        'status' => 'required'
        ]);
        $input = $request->all();
        Type::create($input);
        return redirect()->action('TypesController@index');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $categories = Category::pluck('name','id');
        $categories['']='Select Category';
        $result = Type::findOrFail($id);
        return view('types.create',compact('result','categories')); 
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
         $this->validate($request, [
        'type_name' => 'required',
        'category_id' => 'required',
        'status' => 'required'
        ]);
        Type::where('id', $id)->update(array(
            'type_name'    =>$request->input('type_name'),
            'category_id'    =>$request->input('category_id'),
            'status'    =>$request->input('status')
        ));
        return redirect()->action('TypesController@index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
          DB::table('types')->where('id', '=',$id)->delete();
          return redirect()->action('TypesController@index');
    }
}
