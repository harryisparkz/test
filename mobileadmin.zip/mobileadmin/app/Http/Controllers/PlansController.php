<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Plan;
use App\Category;

class PlansController extends Controller
{
    public function __construct()
     {
        $this->middleware('auth');
     }   
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $plans=Plan::with('categories')->get();
        return view('plans.index',compact('plans'));
    }

    

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
         $categories = Category::pluck('name','id');
         $categories['']='Select Category';   
         return view('plans.create',compact('categories'));
       
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
         $this->validate($request, [
        'plan_name' => 'required',
        'category_id' => 'required',
        'status' => 'required'
        ]);
        $input = $request->all();
        Plan::create($input);
        return redirect()->action('PlansController@index');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $categories = Category::pluck('name','id');
        $categories['']='Select Category';
        $result = Plan::findOrFail($id);
        return view('plans.create',compact('result','categories')); 
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $this->validate($request, [
        'plan_name' => 'required',
        'category_id' => 'required',
        'status' => 'required'
        ]);
        Plan::where('id', $id)->update(array(
            'plan_name'    =>$request->input('plan_name'),
            'category_id'    =>$request->input('category_id'),
            'status'    =>$request->input('status')
        ));
        return redirect()->action('PlansController@index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
          DB::table('plans')->where('id', '=',$id)->delete();
          return redirect()->action('PlansController@index');
    }
 
}
