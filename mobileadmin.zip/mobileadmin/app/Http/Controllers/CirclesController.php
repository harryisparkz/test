<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Circle;
use App\Category;
use App\State;
use App\User;
use \Crypt;

class CirclesController extends Controller
{
     public function __construct()
     {
        $this->middleware('auth');
     }   
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $circles = DB::table('circles')
            ->join('categories', 'categories.id', '=', 'circles.category_id')
            ->join('states', 'states.id', '=', 'circles.state_id')
            ->select('circles.*', 'categories.name', 'states.name as state_name')
            ->get();
        return view('circles.index',compact('circles'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $categories = Category::pluck('name','id');
        $categories['']='Select Category'; 
        $states = State::pluck('name','id');
        $states['']='Select Category'; 
        return view("circles.create",compact('categories','states'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request, [
        'circle_code'=>'required|max:3',  
        'category_id' => 'required',
        'state_id' => 'required',
        'status' => 'required'
        ]);
         if(Circle::where('state_id',$request->input('state_id'))->Where('category_id',$request->input('category_id'))->count())
         { 
             return redirect('circle/create')->with('circlemsg', 'You have already added this circle code for this Category and State!!');
         }
        if(Circle::where('circle_code',$request->input('circle_code'))->Where('state_id',$request->input('state_id'))->Where('category_id',$request->input('category_id'))->count())
        {
             return redirect('circle/create')->with('circlemsg', 'You have already added this circle code for this Category and State!!');
        }
        $input = $request->all();
        Circle::create($input);
        return redirect()->action('CirclesController@index');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
      $categories = Category::pluck('name','id');
      $categories['']='Select Category'; 
      $states = State::pluck('name','id');
      $states['']='Select Category';
      $result = Circle::findOrFail($id);
      return view('circles.create',compact('result','categories','states')); 
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {

        $this->validate($request, [
        'circle_code'=>'required|max:3',  
        'category_id' => 'required',
        'state_id' => 'required',
        'status' => 'required'
        ]);
         if(Circle::where('state_id',$request->input('state_id'))->Where('category_id',$request->input('category_id'))->count())
         { 
             return redirect('circle/'.$id.'/edit')->with('circlemsg', 'You have already added this circle code for this Category and State!!');
         }
        if(Circle::where('circle_code',$request->input('circle_code'))->Where('state_id',$request->input('state_id'))->Where('category_id',$request->input('category_id'))->count())
        {
             return redirect('circle/'.$id.'/edit')->with('circlemsg', 'You have already added this circle code for this Category and State!!');
        }
        Circle::where('id', $id)->update(array(
            'circle_code'    =>$request->input('circle_code'),
            'category_id'    =>$request->input('category_id'),
            'state_id'    =>$request->input('state_id'),
            'status'    =>$request->input('status')
        ));
         return redirect()->action('CirclesController@index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
          DB::table('circles')->where('id', '=',$id)->delete();
          return redirect()->action('CirclesController@index');
    }
}
