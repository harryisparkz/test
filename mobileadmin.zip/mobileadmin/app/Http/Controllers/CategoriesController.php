<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Category;
use \Crypt;
class CategoriesController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    } 
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    
    public function index()
    {
      $categories = DB::table('categories')->orderBy('id', 'asc')->paginate(2);
      return view('categories.index',['result'=>$categories]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return  view('categories.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request, [
        'url_key' => 'required',
        'name' => 'required',
        'status' => 'required'
        ]);
   	    $input = $request->all();
        Category::create($input);
        return redirect()->action('CategoriesController@index');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
      //Crypt::decrypt($id);
      $result = Category::findOrFail($id);
      return view('categories.create',compact('result'));    
}

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
         $this->validate($request, [
        'url_key' => 'required',
        'name' => 'required',
        'status' => 'required'
        ]);
        Category::where('id', $id)->update(array(
            'name'    =>$request->input('name'),
            'url_key'    =>$request->input('url_key'),
            'status'    =>$request->input('status')
        ));
        return redirect()->action('CategoriesController@index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
          DB::table('categories')->where('id', '=',$id)->delete();
          return redirect()->action('CategoriesController@index');
    }
}
