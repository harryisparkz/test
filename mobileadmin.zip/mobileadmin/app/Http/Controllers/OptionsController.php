<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Option;
use App\Category;

class OptionsController extends Controller
{
    public $field=[''=>'Select Type','text'=>'text','textarea'=>'textarea'];
  
    public function __construct()
     {
        $this->middleware('auth');
     }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $options=Option::with('categories')->get();
        return view('options.index',compact('options'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
         $field=$this->field;
         $categories = Category::pluck('name','id');
         $categories['']='Select Category';   
         return view('options.create',compact('categories','field'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
         $this->validate($request, [
        'option_label' => 'required',
        'option_name' => 'required',
        'option_type' => 'required',
        'category_id' => 'required',
        'status' => 'required'
        ]);

        $options=new Option;
        $options->category_id=$request->input('category_id');
        $options->option_name=str_replace(' ','',strtolower($request->input('option_name')));
        $options->option_label=$request->input('option_label');
        $options->option_type=$request->input('option_type');
        $options->status=$request->input('status');
        if($options->save())
        {      
        return redirect()->action('OptionsController@index');
        } 
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
         
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $field=$this->field; 
        $categories = Category::pluck('name','id');
        $categories['']='Select Category';
        $result = Option::findOrFail($id);
        return view('options.create',compact('result','categories','field'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
         $this->validate($request, [
        'option_label' => 'required',
        'option_name' => 'required',
        'option_type' => 'required',
        'category_id' => 'required',
        'status' => 'required'
        ]);
        Option::where('id', $id)->update(array(
            'option_type'=>$request->input('option_type'),
            'option_label'=>$request->input('option_label'),
            'option_name'=>str_replace(' ','',strtolower($request->input('option_name'))),
            'category_id'=>$request->input('category_id'),
            'status'=>$request->input('status')
        ));
        return redirect()->action('OptionsController@index');
         
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
           DB::table('options')->where('id', '=',$id)->delete();
          return redirect()->action('OptionsController@index');
    }
}
