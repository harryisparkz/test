<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Type extends Model
{
     protected $fillable = ['type_name','category_id','status']; 

    public function categories()
     {
        return $this->belongsTo('App\Category','category_id');
     }
}
