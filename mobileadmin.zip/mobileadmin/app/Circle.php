<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Circle extends Model
{
    protected $fillable = [
        'category_id', 'state_id','circle_code','status',
    ];
  
    public function states()
     {
        return $this->belongsTo('App\State','state_id');
     }

}
