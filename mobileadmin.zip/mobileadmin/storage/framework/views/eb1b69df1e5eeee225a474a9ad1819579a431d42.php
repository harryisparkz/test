<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
               <span><a  class="btn btn-primary" href="<?php echo e(url('/operator/create')); ?>">Add Operator</a></span>
                <div class="panel-heading">View Operator</div>
                <div class="panel-body">
                <table class="table">
<tr>
<th>Operator Id </th>
<th>Category Name </th>
<th>Operator Name </th>
<th>Operator Code </th>
<th>Operator Status </th>
<th colspan="2">Apply Action</th>
</tr>
 <tbody>
<?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
<?php $__currentLoopData = $data->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $operatordata): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
<tr>
<td><?php echo e($data->id); ?></td>
<td><?php echo e($data->name); ?></td>
<td><?php echo e($operatordata->operator_name); ?></td>
<td><?php echo e($operatordata->operator_code); ?></td>
<td><?php if($operatordata->status == 1): ?> Enable <?php else: ?> Disable <?php endif; ?></td>
<td><a href="<?php echo e(route('operator.edit', $operatordata->id)); ?>" class="btn btn-primary">Edit</a></td><td><?php echo Form::open([
            'method' => 'DELETE',
            'route' => ['operator.destroy', $operatordata->id]
        ]); ?>

            <?php echo Form::submit('Delete', ['class' => 'btn btn-primary']); ?>

        <?php echo Form::close(); ?></td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
</tbody>
</table>
<div class="pagination">

</div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>