<?php $__env->startSection('content'); ?>
<div class="container" ng-app="validationApp" ng-controller="mainController">
<div class="row">
<div class="panel panel-default">
<span><a  class="btn btn-success" href="<?php echo e(url('/plan/')); ?>">View Type</a></span>
<div class="panel-heading">Add Type</div>
<div class="panel-body">

<?php if(isset($result)): ?>
<?php echo e(Form::model($result, ['route' => ['type.update', $result->id], 'method' => 'PATCH','class'=>'col-md-4','name'=>'planform','ng-submit'=>'submitForm(typeform.$valid)'])); ?>

<?php else: ?>
<?php echo Form::open(['route'=>'type.store', 'method' => 'POST','class'=>'col-md-4','name'=>'typeform','ng-submit'=>'submitForm(typeform.$valid)']); ?>

<?php endif; ?>
<div class="form-group">
<?php echo Form::label('Select Category'); ?>

<?php echo Form::select('category_id',$categories,null,['class'=>'form-control','autocomplete'=>'off']); ?>

<?php if($errors->has('category_id')): ?>
<span class="help-block">
<strong><?php echo e($errors->first('category_id')); ?></strong>
</span>
<?php endif; ?>
</div>
<div class="form-group">
<?php echo Form::label('Type Name:'); ?>

<?php echo Form::text('type_name',null,['class'=>'form-control','autocomplete'=>'off']); ?>

<?php if($errors->has('type_name')): ?>
<span class="help-block">
<strong><?php echo e($errors->first('type_name')); ?></strong>
</span>
<?php endif; ?>
</div>
<div class="form-group">
<?php echo Form::label('Operator Status:'); ?>

<?php echo Form::select('status',[null=>'Select Status','1' => 'Enable', '0' => 'Disable'],null,['class'=>'form-control']); ?>

<?php if($errors->has('status')): ?>
<span class="help-block">
<strong><?php echo e($errors->first('status')); ?></strong>
</span
 <?php endif; ?>
 </div>
<div class="form-group">
<?php echo Form::submit("Save & Update",['class'=>'btn btn-success','ng-disabled'=>'typeform.$invalid']); ?>

 </div>
<?php echo Form::close(); ?>

</div>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>