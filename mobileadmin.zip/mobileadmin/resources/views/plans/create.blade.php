@extends('layouts.app')
@section('content')
<div class="container" ng-app="validationApp" ng-controller="mainController">
<div class="row">
<div class="panel panel-default">
<span><a  class="btn btn-success" href="{{ url('/plan/') }}">View Plan</a></span>
<div class="panel-heading">Add Plan</div>
<div class="panel-body">

@if(isset($result))
{{ Form::model($result, ['route' => ['plan.update', $result->id], 'method' => 'PATCH','class'=>'col-md-4','name'=>'planform','ng-submit'=>'submitForm(planform.$valid)']) }}
@else
{!! Form::open(['route'=>'plan.store', 'method' => 'POST','class'=>'col-md-4','name'=>'planform','ng-submit'=>'submitForm(planform.$valid)']) !!}
@endif
<div class="form-group">
{!! Form::label('Select Category') !!}
{!! Form::select('category_id',$categories,null,['class'=>'form-control','autocomplete'=>'off']) !!}
@if ($errors->has('category_id'))
<span class="help-block">
<strong>{{ $errors->first('category_id') }}</strong>
</span>
@endif
</div>
<div class="form-group">
{!! Form::label('Plan Name:') !!}
{!! Form::text('plan_name',null,['class'=>'form-control','autocomplete'=>'off']) !!}
@if ($errors->has('plan_name'))
<span class="help-block">
<strong>{{ $errors->first('plan_name') }}</strong>
</span>
@endif
</div>
<div class="form-group">
{!! Form::label('Operator Status:') !!}
{!! Form::select('status',[null=>'Select Status','1' => 'Enable', '0' => 'Disable'],null,['class'=>'form-control']) !!}
@if ($errors->has('status'))
<span class="help-block">
<strong>{{ $errors->first('status') }}</strong>
</span
 @endif
 </div>
<div class="form-group">
{!! Form::submit("Save & Update",['class'=>'btn btn-success','ng-disabled'=>'planform.$invalid']) !!}
 </div>
{!! Form::close() !!}
</div>
</div>
</div>
</div>
@endsection
