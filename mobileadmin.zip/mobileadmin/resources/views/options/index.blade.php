@extends('layouts.app')
@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
               <span><a  class="btn btn-success" href="{{ url('/option/create') }}">Add Option</a></span>
                <div class="panel-heading">View Option</div>
                <div class="panel-body">
                <table class="table">
<tr>
<th>Option Id </th>
<th>Category Name</th>
<th>Option Name </th>
<th>Option Label</th>
<th>Option Type </th>
<th>Option Status </th>
<th colspan="2">Apply Action</th>
</tr>
 <tbody>
@foreach ($options as $data)
<tr>
<td>{{$data->id}}</td>
<td>{{ $data->categories->name}}</td>
<td>{{ $data->option_name}}</td>
<td>{{ $data->option_label}}</td>
<td>{{ $data->option_type}}</td>
<td>@if ($data->status == 1) Enable @else Disable @endif</td>
<td><a href="{{ route('option.edit', $data->id) }}" class="btn btn-success">Edit</a></td><td>{!! Form::open([
            'method' => 'DELETE',
            'route' => ['option.destroy',  $data->id]
        ]) !!}
            {!! Form::submit('Delete', ['class' => 'btn btn-success']) !!}
        {!! Form::close() !!}</td>
</tr>
@endforeach
</tbody>
</table>
<div class="pagination">

</div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
