@extends('layouts.app')
@section('content')
<div class="container" ng-app="validationApp" ng-controller="mainController">
<div class="row">
<div class="panel panel-default">
<span><a  class="btn btn-success" href="{{ url('/categories/') }}">View Category</a></span>
<div class="panel-heading">Add Category</div>
<div class="panel-body">

@if(isset($result))
{{ Form::model($result, ['route' => ['categories.update', $result->id], 'method' => 'PATCH','class'=>'col-md-4','name'=>'categoryform','ng-submit'=>'submitForm(categoryform.$valid)']) }}
@else
{!! Form::open(['route'=>'categories.store', 'method' => 'POST','class'=>'col-md-4','name'=>'categoryform','ng-submit'=>'submitForm(categoryform.$valid)']) !!}
@endif
<div class="form-group">
{!! Form::label('Category Name:') !!}
{!! Form::text('name',null,['class'=>'form-control','autocomplete'=>'off']) !!}
@if ($errors->has('name'))
<span class="help-block">
<strong>{{ $errors->first('name') }}</strong>
</span>
@endif
 </div>
<div class="form-group">
{!! Form::label('Category Url Key:') !!}
{!! Form::text('url_key',null,['class'=>'form-control','autocomplete'=>'off']) !!}
@if ($errors->has('url_key'))
<span class="help-block">
<strong>{{ $errors->first('url_key') }}</strong>
</span>
@endif
</div>
<div class="form-group">
{!! Form::label('Category Status:') !!}
{!! Form::select('status',[null=>'Select Status','1' => 'Enable', '0' => 'Disable'],null,['class'=>'form-control']) !!}
@if ($errors->has('status'))
<span class="help-block">
<strong>{{ $errors->first('status') }}</strong>
</span
 @endif
 </div>
<div class="form-group">
{!! Form::submit("Save & Update",['class'=>'btn btn-success','ng-disabled'=>'categoryform.$invalid']) !!}
 </div>
{!! Form::close() !!}
</div>
</div>
</div>
</div>
@endsection
