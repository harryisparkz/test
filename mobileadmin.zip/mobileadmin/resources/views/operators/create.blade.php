@extends('layouts.app')
@section('content')
<div class="container" ng-app="validationApp" ng-controller="mainController">
<div class="row">
<div class="panel panel-default">
<span><a  class="btn btn-success" href="{{ url('/operator/') }}">View Operator</a></span>
<div class="panel-heading">Add Operator</div>
<div class="panel-body">

@if(isset($result))
{{ Form::model($result, ['route' => ['operator.update', $result->id], 'method' => 'PATCH','class'=>'col-md-4','name'=>'operatorform','ng-submit'=>'submitForm(operatorform.$valid)']) }}
@else
{!! Form::open(['route'=>'operator.store', 'method' => 'POST','class'=>'col-md-4','name'=>'operatorform','ng-submit'=>'submitForm(operatorform.$valid)']) !!}
@endif
<div class="form-group">
{!! Form::label('Select Category') !!}
{!! Form::select('category_id',$categories,null,['class'=>'form-control','autocomplete'=>'off']) !!}
@if ($errors->has('category_id'))
<span class="help-block">
<strong>{{ $errors->first('category_id') }}</strong>
</span>
@endif
</div>
<div class="form-group">
{!! Form::label('Operator Name:') !!}
{!! Form::text('operator_name',null,['class'=>'form-control','autocomplete'=>'off']) !!}
@if ($errors->has('operator_name'))
<span class="help-block">
<strong>{{ $errors->first('operator_name') }}</strong>
</span>
@endif
</div>
<div class="form-group">
{!! Form::label('Operator Code:') !!}
{!! Form::text('operator_code',null,['class'=>'form-control','autocomplete'=>'off']) !!}
@if ($errors->has('operator_code'))
<span class="help-block">
<strong>{{ $errors->first('operator_code') }}</strong>
</span>
@endif
</div>
<div class="form-group">
{!! Form::label('Operator Status:') !!}
{!! Form::select('status',[null=>'Select Status','1' => 'Enable', '0' => 'Disable'],null,['class'=>'form-control']) !!}
@if ($errors->has('status'))
<span class="help-block">
<strong>{{ $errors->first('status') }}</strong>
</span
 @endif
 </div>
<div class="form-group">
{!! Form::submit("Save & Update",['class'=>'btn btn-success','ng-disabled'=>'operatorform.$invalid']) !!}
 </div>
{!! Form::close() !!}
</div>
</div>
</div>
</div>
@endsection
