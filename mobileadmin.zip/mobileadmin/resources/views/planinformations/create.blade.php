@extends('layouts.app')
@section('content')
	<script>
 	var myApp = angular.module('myApp',['ngMessages']);
    /* Config */
    myApp.config(function($interpolateProvider) {
    $interpolateProvider.startSymbol('//');
    $interpolateProvider.endSymbol('//');
    });
	/* Controller*/
	myApp.controller('dropdownCtrl',['$http','$filter','$scope','PlanService', function($http,$filter,$scope,PlanService) {
	    $scope.update_record={};
      $scope.records={};
      $scope.optionrecord={};
      $scope.customer ={
	         Category:'',
	         Operator:'',
	         Type:'',
	         Circle:'',
	         Plan:''
	     };
   $scope.isSave=true;
   $scope.isUpdate=false; 
   $scope.isCancel=false; 
   $scope.isCircle=true;  
   $scope.isType=true;  
   $scope.categories = PlanService.getCategory();
  
	 $scope.getCategoryList = function(){
      if($scope.customer.Category==""|| typeof $scope.customer.Category === "undefined" || isNaN($scope.customer.Category))
      {
      $scope.reset();
	    return false;
      }
      $scope.operators = PlanService.getOperatorList($scope.customer.Category);
	    $scope.types = PlanService.getTypeList($scope.customer.Category);
	    $scope.circles = PlanService.getCircleList($scope.customer.Category);
	    $scope.plans = PlanService.getPlanList($scope.customer.Category);
      if($scope.circles=="")
      {
       $scope.isCircle=false;
      } 
       if($scope.types=="")
      {
       $scope.isType=false;
      } 
	  };

	 
   /*updateData  Record */
  $scope.updateData=function()
   {
 
  $scope.customer.category_name="";
  $scope.customer.operator_name="";
  $scope.customer.type_name="";
  $scope.customer.state_name="";
  $scope.customer.plan_name="";
  if($scope.customer.Category==""|| typeof $scope.customer.Category === "undefined" || isNaN($scope.customer.Category))
  $scope.customer.Category="";
  else
  $scope.customer.category_name=($filter('filter')($scope.categories ,{id: $scope.customer.Category})[0].name);
  if($scope.customer.Operator=="" || typeof $scope.customer.Operator === "undefined" || isNaN($scope.customer.Operator))
     $scope.customer.Operator="";
  else
  $scope.customer.operator_name=($filter('filter')($scope.operators ,{id: $scope.customer.Operator})[0].operator_name); 
  if($scope.customer.Type=="" || typeof $scope.customer.Type === "undefined" || isNaN($scope.customer.Type))
     $scope.customer.Type="";
  else
  $scope.customer.type_name=($filter('filter')($scope.types ,{id: $scope.customer.Type})[0].type_name); 
  if($scope.customer.Circle=="" || typeof $scope.customer.Circle === "undefined" || isNaN($scope.customer.Circle))
      $scope.customer.Circle="";
  else
  $scope.customer.state_name=($filter('filter')($scope.circles,{id: $scope.customer.Circle})[0].states.name);  
  if($scope.customer.Plan=="" || typeof $scope.customer.Plan === "undefined" || isNaN($scope.customer.Plan))
     $scope.customer.Plan="";
  else
  $scope.customer.plan_name=($filter('filter')($scope.plans,{id: $scope.customer.Plan})[0].plan_name);  
 
  $params = $.param({'info_id':$scope.update_record.info_id,'category_id':$scope.customer.Category,'operator_id':$scope.customer.Operator,'type_id':$scope.customer.Type,'circle_id':$scope.customer.Circle,'plan_id':$scope.customer.Plan,'data':$scope.customer});  
  
   $http({
        headers: {'Content-Type': 'application/x-www-form-urlencoded','X-CSRF-Token': $('input[name="_token"]').val()},
        url:"<?php echo url('/plan_information/updaterecord');?>",
        method: 'POST',
        data:$params,
        dataType: 'json'
        }).then(function(response){
           $scope.reset();
           $scope.fetchrecord();
        });  
   };

   /*Save Record */
  $scope.saverecord=function()
   {
   if ($scope.planInfo.$invalid) {
   alert("Please select required field");
   return false;
   }
  $scope.customer.category_name="";
  $scope.customer.operator_name="";
  $scope.customer.type_name="";
  $scope.customer.state_name="";
  $scope.customer.plan_name="";
  $scope.update_record="";
  if($scope.customer.Category==""|| typeof $scope.customer.Category === "undefined" || isNaN($scope.customer.Category))
  $scope.customer.Category="";
  else
  $scope.customer.category_name=($filter('filter')($scope.categories ,{id: $scope.customer.Category})[0].name);
  if($scope.customer.Operator=="" || typeof $scope.customer.Operator === "undefined" || isNaN($scope.customer.Operator))
     $scope.customer.Operator="";
  else
  $scope.customer.operator_name=($filter('filter')($scope.operators ,{id: $scope.customer.Operator})[0].operator_name); 
  if($scope.customer.Type=="" || typeof $scope.customer.Type === "undefined" || isNaN($scope.customer.Type))
     $scope.customer.Type="";
  else
  $scope.customer.type_name=($filter('filter')($scope.types ,{id: $scope.customer.Type})[0].type_name); 
  if($scope.customer.Circle=="" || typeof $scope.customer.Circle === "undefined" || isNaN($scope.customer.Circle))
      $scope.customer.Circle="";
  else
  $scope.customer.state_name=($filter('filter')($scope.circles,{id: $scope.customer.Circle})[0].states.name);  
  if($scope.customer.Plan=="" || typeof $scope.customer.Plan === "undefined" || isNaN($scope.customer.Plan))
     $scope.customer.Plan="";
  else
  $scope.customer.plan_name=($filter('filter')($scope.plans,{id: $scope.customer.Plan})[0].plan_name);  
 
  $params = $.param({'category_id':$scope.customer.Category,'operator_id':$scope.customer.Operator,'type_id':$scope.customer.Type,'circle_id':$scope.customer.Circle,'plan_id':$scope.customer.Plan,'data':$scope.customer});  
  
   $http({
        headers: {'Content-Type': 'application/x-www-form-urlencoded','X-CSRF-Token': $('input[name="_token"]').val()},
        url:"<?php echo url('/plan_information/saverecord');?>",
        method: 'POST',
        data:$params,
        dataType: 'json'
        }).then(function(response){
           $scope.reset();
           $scope.fetchrecord();
        });  
   };




  /* Edit Row*/
  $scope.editRow=function(editData)
  {
    $scope.isSave=false;
    $scope.isUpdate=true;
    $scope.isCancel=true;
    $scope.update_record=editData;
    $scope.customer.Category = parseInt(editData.result.Category);

    $scope.operators = PlanService.getOperatorList($scope.customer.Category);
    $scope.customer.Operator = parseInt(editData.result.Operator);

    $scope.types = PlanService.getTypeList($scope.customer.Category);
    $scope.customer.Type = parseInt(editData.result.Type);

    $scope.circles = PlanService.getCircleList($scope.customer.Category);
    $scope.customer.Circle = parseInt(editData.result.Circle);

    $scope.plans = PlanService.getPlanList($scope.customer.Category);
    $scope.customer.Plan = parseInt(editData.result.Plan);
  
    $scope.customer.talktime=editData.result.talktime;

    $scope.customer.price=editData.result.price;

    $scope.customer.validity=editData.result.validity;

    $scope.customer.benefits=editData.result.benefits;
  };


 /* Remove record */
 
 $scope.removeRow = function(id){ 
   var  val=confirm("Do you want to delete Record ?");
   if(val==false)
   return false;    
   var index = -1;    
   var comArr = eval($scope.records);
    for( var i = 0; i < comArr.length; i++ ) {
      console.log(comArr[i]);
      if( comArr[i].info_id === id ) {
        index = i;
        $scope.deleteRecord(id);
        break;
      }
    }
    if( index === -1 ) {
      alert( "Something gone wrong" );
    }
    $scope.records.splice(index,1);    
  };


   /* Reset Record*/
   $scope.reset=function()
   {
      $(".form-control").val("");
      $scope.isSave=true;
      $scope.isUpdate=false;
      $scope.isCancel=false;
      $scope.customer.Category="";
      $scope.customer.Operator="";
      $scope.customer.Type="";
      $scope.customer.Circle="";
      $scope.customer.Plan="";

      $scope.customer.talktime="";
      $scope.customer.validity="";
      $scope.customer.benefits="";
      $scope.customer.price="";
      $scope.operators="";
      $scope.types="";
      $scope.circles="";
      $scope.plans="";
 
   }; 


/* cancel  Data*/
  $scope.cancelData=function()
  {  
      $(".form-control").val("");
      $scope.isSave=true;
      $scope.isUpdate=false;
      $scope.isCancel=false;
      $scope.customer= angular.copy($scope.update_record);
      $scope.customer.Category="";
      $scope.customer.Operator="";
      $scope.customer.Type="";
      $scope.customer.Circle="";
      $scope.customer.Plan="";

      $scope.operators="";
      $scope.types="";
      $scope.circles="";
      $scope.plans="";

  };
 
 /*Get Record */
$scope.fetchrecord=function()
   {
        $http({
        headers: {'Content-Type': 'application/x-www-form-urlencoded','X-CSRF-Token': $('input[name="_token"]').val()},
        url:"<?php echo url('/plan_information/getrecord');?>",
        method: 'GET',
        }).then(function(response){
          $scope.records=response.data;
          console.log($scope.records);
        });
   }
  

 /* Delete record */
$scope.deleteRecord=function(id) {
           $params = $.param({'id':id}); 
            $http({
                    headers: {'Content-Type': 'application/x-www-form-urlencoded','X-CSRF-Token': $('input[name="_token"]').val()},
                    url:"<?php echo url('/plan_information/deleterecord');?>",
                    method: 'POST',
                    data:$params,
                    dataType: 'json'
                }).then(function(response){
                  $scope.reset();
                });
                
 }

  $scope.fetchrecord();


}]);
 
  /* Factory*/
	myApp.factory("PlanService", ['$http','$filter', function($http,$filter){
	var service = {};
	var cagetorylist =<?php echo $cagetorylist?>;
	var operatorlist =<?php echo $operatorlist?>;
	var typelist=<?php echo $typelist?>;
	var circlelist=<?php echo $circlelist?>;  
	var planlist=<?php echo $planlist?>;  
	
	service.getCategory = function(result){    
    return cagetorylist;
    };

    service.getOperatorList = function(category_id){
    var operators = ($filter('filter')(operatorlist, {category_id: category_id}));
    return operators;
    };

    service.getTypeList = function(category_id){
    var types = ($filter('filter')(typelist, {category_id: category_id}));
    return types;
    };

    service.getCircleList = function(category_id){
    var circles = ($filter('filter')(circlelist, {category_id: category_id}));
    return circles;
    };

    service.getPlanList = function(category_id){
    var plans = ($filter('filter')(planlist, {category_id: category_id}));
    return plans;
    };

	return service;
  	}]);
      </script>
<div class="container" ng-app="myApp"  ng-controller="dropdownCtrl" >
<div class="row">
<div class="col-md-12">
<div class="panel panel-default">
<div class="panel-heading">Add Information</div>
<div class="panel-body">

<form name="planInfo" id="planInfo"  novalidate>
	 <div class="form-group">
	      <label for="country" class="col-sm-2 control-label">Category</label>
	              
	        <select ng-model="customer.Category"
                  name="customer.Category"  
	                ng-options="obj.id as obj.name for obj in categories"
	                ng-change="getCategoryList()"
	                class="form-control" 
	                ng-required="true"
                  id="country">
	          <option value="">-- Choose Category --</option>
	        </select>      
	    </div>
   <div ng-messages="planInfo['customer.Category'].$error" ng-if="planInfo['customer.Category'].$touched" style="color:red" role="alert">
     <div ng-message="required" class="help-block">Category is required.</div>
    </div> 

      <div class="form-group">
      <label for="state" class="col-sm-2 control-label">Operator</label>
        <select ng-model="customer.Operator"
                name="customer.Operator"   
                ng-options="x.id as x.operator_name for x in operators"
                class="form-control"
                ng-disabled="!operators || operators.length==0"
              
                id="state">
          <option value="">-- Choose Operator--</option>
        </select>      
    </div>

      <div class="form-group">
      <label for="state" class="col-sm-2 control-label">Type</label>
        <select ng-model="customer.Type" 
                name="customer.Type" 
                ng-options="x.id as x.type_name for x in types"
                class="form-control"
                ng-disabled="!types || types.length==0"
                id="state">
          <option value="">-- Choose Type--</option>
        </select>      
    </div>


    <div ng-messages="planInfo['customer.Type'].$error" ng-if="planInfo['customer.Type'].$touched" style="color:red" role="alert">
     <div ng-message="required" class="help-block">Type is required.</div>
    </div> 
     
      <div class="form-group">
      <label for="state" class="col-sm-2 control-label">Circle</label>
        <select ng-model="customer.Circle"
                name="customer.Circle"    
                ng-options="x.id as x.states.name for x in circles"
                class="form-control"
                ng-disabled="!circles || circles.length==0"
                id="state">
          <option value="">-- Choose Circle--</option>
        </select>      
    </div>
 
    <div class="form-group">
      <label for="state" class="col-sm-2 control-label">Plan</label>
        <select ng-model="customer.Plan" 
                name="customer.Plan"  
                ng-options="x.id as x.plan_name for x in plans"
                class="form-control"
                ng-disabled="!plans || plans.length==0"
                id="state">
          <option value="">-- Choose Plan--</option>
        </select>      
    </div>
   
   <div class="form-group">
      <label for="usr">Talk Time for mobile:</label>
      <input type="text" class="form-control" ng-model='customer  .talktime' id="usr">
   
   </div>
   <div class="form-group">
      <label for="usr">Validity:</label>
      <input type="text" class="form-control" ng-model='customer.validity' id="usr">
   
   </div>
   <div class="form-group">
      <label for="usr">Description:</label>
      <textarea class="form-control" rows="5" id="comment" ng-model='customer.benefits'></textarea>
   
   </div>
   <div class="form-group">
      <label for="usr">Price:</label>
      <input type="text" class="form-control" ng-model='customer.price' id="usr">
   
   </div>
    
  <button type="submit" class="btn btn-success" ng-click="saverecord()" ng-show = "isSave" >Save Information</button>
  <button type="button" class="btn btn-success" ng-show = "isUpdate" ng-click="updateData()">Update Information</button>
  <button type="button" class="btn btn-success" ng-show = "isCancel" ng-click="cancelData()">Cancel</button>
 </form>  
</div>
</div>
</div>
<div class="col-md-12">
 <table class="table">
  <tr> 
   <th>Category</th>
   <th>Operator</th>
   <th>Type</th>
   <th>Circle</th>
   <th>Plan</th>
   <th>Talk Time</th>
   <th>Validity</th>
   <th>Data Benefits</th>
   <th>Price</th>
   <th colspan="2">Action</th>
   </tr>
  <tr ng-repeat="record in records">
   <td>//record.result.category_name//</td>
   <td>//record.result.operator_name//</td>
   <td>//record.result.type_name//</td>
   <td>//record.result.state_name//</td>
   <td>//record.result.plan_name//</td>
   <td>//record.result.talktime//</td>
   <td>//record.result.validity//</td>
   <td>//record.result.benefits//</td>
   <td>//record.result.price//</td>
   <td><a class="btn btn-success" href="javascript:void(0)" ng-click="removeRow(record.info_id)">Delete</a></td>
   <td><a class="btn btn-success" href="javascript:void(0)" ng-click="editRow(record)">Edit</a></td>
   </tr>
 </table>
</div>
</div>
</div>
@endsection


