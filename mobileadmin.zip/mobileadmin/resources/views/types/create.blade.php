@extends('layouts.app')
@section('content')
<div class="container" ng-app="validationApp" ng-controller="mainController">
<div class="row">
<div class="panel panel-default">
<span><a  class="btn btn-success" href="{{ url('/plan/') }}">View Type</a></span>
<div class="panel-heading">Add Type</div>
<div class="panel-body">

@if(isset($result))
{{ Form::model($result, ['route' => ['type.update', $result->id], 'method' => 'PATCH','class'=>'col-md-4','name'=>'planform','ng-submit'=>'submitForm(typeform.$valid)']) }}
@else
{!! Form::open(['route'=>'type.store', 'method' => 'POST','class'=>'col-md-4','name'=>'typeform','ng-submit'=>'submitForm(typeform.$valid)']) !!}
@endif
<div class="form-group">
{!! Form::label('Select Category') !!}
{!! Form::select('category_id',$categories,null,['class'=>'form-control','autocomplete'=>'off']) !!}
@if ($errors->has('category_id'))
<span class="help-block">
<strong>{{ $errors->first('category_id') }}</strong>
</span>
@endif
</div>
<div class="form-group">
{!! Form::label('Type Name:') !!}
{!! Form::text('type_name',null,['class'=>'form-control','autocomplete'=>'off']) !!}
@if ($errors->has('type_name'))
<span class="help-block">
<strong>{{ $errors->first('type_name') }}</strong>
</span>
@endif
</div>
<div class="form-group">
{!! Form::label('Operator Status:') !!}
{!! Form::select('status',[null=>'Select Status','1' => 'Enable', '0' => 'Disable'],null,['class'=>'form-control']) !!}
@if ($errors->has('status'))
<span class="help-block">
<strong>{{ $errors->first('status') }}</strong>
</span
 @endif
 </div>
<div class="form-group">
{!! Form::submit("Save & Update",['class'=>'btn btn-success','ng-disabled'=>'typeform.$invalid']) !!}
 </div>
{!! Form::close() !!}
</div>
</div>
</div>
</div>
@endsection
