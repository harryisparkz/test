<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Information extends Model
{
     protected $fillable = ['category_id','operator_id','type_id','circle_id','plan_id','description','status']; 

     protected $table = 'plan_information'; 
}
