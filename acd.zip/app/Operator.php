<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Operator extends Model
{
     protected $fillable = ['operator_name','operator_code','category_id','status']; 
     
     public function categories()
     {
        return $this->belongsTo('App\Category','category_id');
     }
 
}
