<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Plan;
use App\Category;
use App\Operator;
use App\Circle;
use App\Type;
use App\Option;
use App\Information;

class Plan_InformationsController extends Controller
{
     public function __construct()
     {
        $this->middleware('auth');
     }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
          
    }
    
    /* Ajax delete*/

    public  function deleterecord(Request $request)
    {
               
               if($request->isMethod('post')){
                 
                 if(DB::table('plan_information')->where('id', '=',$request->input('id'))->delete())
                 {
                     return response()->json(['success'=>1]);
             
                 }  
                 return response()->json(['success'=>0]);
            
              }

    }

    /* Ajax get*/
    public function getrecord()
    { 
          $result=[];
          $information= DB::table('plan_information')->select('id','description')->get();
          foreach ($information as $key => $value) {
           $result[]=['result'=>unserialize($value->description),'info_id'=>$value->id]; 
          
          }
          return response()->json($result);
          
    }

 /* Ajax Function */
    public function updaterecord(Request $request)
    {
        if($request->isMethod('post')){
           
           $category_id=$request->input('category_id'); 
           $operator_id=$request->input('operator_id'); 
           $type_id=$request->input('type_id'); 
           $circle_id=$request->input('circle_id'); 
           $plan_id=$request->input('plan_id'); 
           $description=serialize($request->input('data')); 
           if(empty($category_id))
           { 
           $category_id=NULL;
           }
           if(empty($operator_id))
           {
           $operator_id=NULL;
           }
           if(empty($type_id))
           {
           $type_id=NULL;
           }
           if(empty($circle_id))
           {
           $circle_id=NULL;
           }
           if(empty($plan_id))
           {
           $plan_id=NULL;
           } 
           $information= Information::find($request->input('info_id'));
           $information->category_id=$category_id;
           $information->operator_id=$operator_id;
           $information->type_id=$type_id;
           $information->circle_id=$circle_id;
           $information->plan_id=$plan_id;
           $information->description=$description;
           $information->status='1';
           if($information->save()) 
           {
             return response()->json(['success'=>1]);
             
           } 
           return response()->json(['success'=>0]);
        }     
        
    }

    /* Ajax Function */
    public function saverecord(Request $request)
    {
        if($request->isMethod('post')){
           
           $category_id=$request->input('category_id'); 
           $operator_id=$request->input('operator_id'); 
           $type_id=$request->input('type_id'); 
           $circle_id=$request->input('circle_id'); 
           $plan_id=$request->input('plan_id'); 
           $description=serialize($request->input('data')); 
           if(empty($category_id))
           { 
           $category_id=NULL;
           }
           if(empty($operator_id))
           {
           $operator_id=NULL;
           }
           if(empty($type_id))
           {
           $type_id=NULL;
           }
           if(empty($circle_id))
           {
           $circle_id=NULL;
           }
           if(empty($plan_id))
           {
           $plan_id=NULL;
           } 
           $information=new Information;
           $information->category_id=$category_id;
           $information->operator_id=$operator_id;
           $information->type_id=$type_id;
           $information->circle_id=$circle_id;
           $information->plan_id=$plan_id;
           $information->description=$description;
           $information->status='1';
           if($information->save()) 
           {
             return response()->json(['success'=>1]);
             
           } 
           return response()->json(['success'=>0]);
        }     
        
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $cagetorylist = Category::all();
        $operatorlist = Operator::all();
        $typelist = Type::all();
        $circlelist = Circle::with('states')->get();
        $planlist = Plan::all();
        $optionlist = Option::all();
        return view('planinformations.create',['cagetorylist'=>$cagetorylist->toJson(),'operatorlist'=>$operatorlist->toJson(),'typelist'=>$typelist->toJson(),'circlelist'=>$circlelist->toJson(),'planlist'=>$planlist->toJson(),'optionlist'=>$optionlist->toJson()]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
