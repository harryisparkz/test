<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Plan extends Model
{
    protected $fillable = ['plan_name','category_id','status']; 

    public function categories()
     {
        return $this->belongsTo('App\Category','category_id');
     }
}
