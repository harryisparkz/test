@extends('layouts.app')
@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
               <span><a  class="btn btn-success" href="{{ url('/state/create') }}">Add State</a></span>
                <div class="panel-heading">View States</div>
                <div class="panel-body">
                <table class="table">
<tr>
<th>States Id </th>
<th>States Name </th>
<th>Category Status </th>
<th colspan="2">Apply Action</th>
</tr>
 <tbody>
@foreach ($result as $data)
<tr>
<td>{{$data->id}}</td>
<td>{{ $data->name}}</td>
<td>@if ($data->status == 1) Enable @else Disable @endif</td>
<td><a href="{{ route('state.edit', $data->id) }}" class="btn btn-success">Edit</a></td><td>{!! Form::open([
            'method' => 'DELETE',
            'route' => ['state.destroy', $data->id]
        ]) !!}
            {!! Form::submit('Delete', ['class' => 'btn btn-success']) !!}
        {!! Form::close() !!}</td>
</tr>
@endforeach
</tbody>
</table>
<div class="pagination">
 {{ $result->render()}} 
</div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

