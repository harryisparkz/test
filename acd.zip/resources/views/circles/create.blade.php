@extends('layouts.app')
@section('content')
<div class="container" ng-app="validationApp" ng-controller="mainController">
<div class="row">
<div class="panel panel-default">
<span><a  class="btn btn-success" href="{{ url('/circle/') }}">View Circle</a></span>
<div class="panel-heading">Add Circle</div>
<div class="panel-body">
@if (session('circlemsg'))
    <div class="alert alert-success">
        {{ session('circlemsg') }}
    </div>
@endif
@if(isset($result))
{{ Form::model($result, ['route' => ['circle.update', $result->id], 'method' => 'PATCH','class'=>'col-md-4','name'=>'circleform','ng-submit'=>'submitForm(circleform.$valid)']) }}
@else
{!! Form::open(['route'=>'circle.store', 'method' => 'POST','class'=>'col-md-4','name'=>'circleform','ng-submit'=>'submitForm(circleform.$valid)']) !!}
@endif
<div class="form-group">
{!! Form::label('Select Category') !!}
{!! Form::select('category_id',$categories,null,['class'=>'form-control','autocomplete'=>'off']) !!}
@if ($errors->has('category_id'))
<span class="help-block">
<strong>{{ $errors->first('category_id') }}</strong>
</span>
@endif
</div>
<div class="form-group">
{!! Form::label('Select State') !!}
{!! Form::select('state_id',$states,null,['class'=>'form-control','autocomplete'=>'off']) !!}
@if ($errors->has('state_id'))
<span class="help-block">
<strong>{{ $errors->first('state_id') }}</strong>
</span>
@endif
</div>
<div class="form-group">
{!! Form::label('Circle Code:') !!}
{!! Form::text('circle_code',null,['class'=>'form-control','autocomplete'=>'off']) !!}
@if ($errors->has('circle_code'))
<span class="help-block">
<strong>{{ $errors->first('circle_code') }}</strong>
</span>
@endif
</div>
<div class="form-group">
{!! Form::label('Circle Status:') !!}
{!! Form::select('status',[null=>'Select Status','1' => 'Enable', '0' => 'Disable'],null,['class'=>'form-control']) !!}
@if ($errors->has('status'))
<span class="help-block">
<strong>{{ $errors->first('status') }}</strong>
</span
 @endif
 </div>
<div class="form-group">
{!! Form::submit("Save & Update",['class'=>'btn btn-success','ng-disabled'=>'operatorform.$invalid']) !!}
 </div>
{!! Form::close() !!}
</div>
</div>
</div>
</div>
@endsection
