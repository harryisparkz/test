@extends('layouts.app')
@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
               <span><a  class="btn btn-success" href="{{ url('/circle/create') }}">Add Circle</a></span>
                <div class="panel-heading">View Circle</div>
                <div class="panel-body">
                <table class="table">
<tr>
<th>Circle Id </th>
<th>Category Name</th>
<th>State Name</th>
<th>Circle Code </th>
<th>Circle Status </th>
<th colspan="2">Apply Action</th>
</tr>
 <tbody>
@foreach ($circles as $data)
<tr>
<td>{{$data->id}}</td>
<td>{{ $data->name}}</td>
<td>{{ $data->state_name}}</td>
<td>{{ $data->circle_code}}</td>
<td>@if ($data->status == 1) Enable @else Disable @endif</td>
<td><a href="{{ route('circle.edit', $data->id) }}" class="btn btn-success">Edit</a></td><td>{!! Form::open([
            'method' => 'DELETE',
            'route' => ['circle.destroy', $data->id]
        ]) !!}
            {!! Form::submit('Delete', ['class' => 'btn btn-success']) !!}
        {!! Form::close() !!}</td>
</tr>
@endforeach
</tbody>
</table>
<div class="pagination">

</div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

