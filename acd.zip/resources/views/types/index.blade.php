@extends('layouts.app')
@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
               <span><a  class="btn btn-success" href="{{ url('/type/create') }}">Add Type</a></span>
                <div class="panel-heading">View Type</div>
                <div class="panel-body">
                <table class="table">
<tr>
<th>Type Id </th>
<th>Category Name </th>
<th>Type Name </th>
<th>Type Status </th>
<th colspan="2">Apply Action</th>
</tr>
 <tbody>
@foreach ($types as $data)
<tr>
<td>{{$data->id}}</td>
<td>{{ $data->categories->name}}</td>
<td>{{ $data->type_name}}</td>
<td>@if ($data->status == 1) Enable @else Disable @endif</td>
<td><a href="{{ route('type.edit', $data->id) }}" class="btn btn-success">Edit</a></td><td>{!! Form::open([
            'method' => 'DELETE',
            'route' => ['type.destroy',  $data->id]
        ]) !!}
            {!! Form::submit('Delete', ['class' => 'btn btn-success']) !!}
        {!! Form::close() !!}</td>
</tr>
@endforeach
</tbody>
</table>
<div class="pagination">

</div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
