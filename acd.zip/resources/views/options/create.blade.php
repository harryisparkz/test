@extends('layouts.app')
@section('content')
<div class="container" ng-app="validationApp" ng-controller="mainController">
<div class="row">
<div class="panel panel-default">
<span><a  class="btn btn-success" href="{{ url('/plan/') }}">View Option</a></span>
<div class="panel-heading">Add Option</div>
<div class="panel-body">

@if(isset($result))
{{ Form::model($result, ['route' => ['option.update', $result->id], 'method' => 'PATCH','class'=>'col-md-4','name'=>'optionform','ng-submit'=>'submitForm(optionform.$valid)']) }}
@else
{!! Form::open(['route'=>'option.store', 'method' => 'POST','class'=>'col-md-4','name'=>'optionform','ng-submit'=>'submitForm(optionform.$valid)']) !!}
@endif
<div class="form-group">
{!! Form::label('Select Category') !!}
{!! Form::select('category_id',$categories,null,['class'=>'form-control','autocomplete'=>'off']) !!}
@if ($errors->has('category_id'))
<span class="help-block">
<strong>{{ $errors->first('category_id') }}</strong>
</span>
@endif
</div>
<div class="form-group">
{!! Form::label('Option Name:') !!}
{!! Form::text('option_name',null,['class'=>'form-control','autocomplete'=>'off']) !!}
@if ($errors->has('option_name'))
<span class="help-block">
<strong>{{ $errors->first('option_name') }}</strong>
</span>
@endif
</div>
<div class="form-group">
{!! Form::label('Option Label:') !!}
{!! Form::text('option_label',null,['class'=>'form-control','autocomplete'=>'off']) !!}
@if ($errors->has('option_label'))
<span class="help-block">
<strong>{{ $errors->first('option_label') }}</strong>
</span>
@endif
</div>
<div class="form-group">
{!! Form::label('Option Type:') !!}
{!! Form::select('option_type',$field,null,['class'=>'form-control','autocomplete'=>'off']) !!}
@if ($errors->has('option_type'))
<span class="help-block">
<strong>{{ $errors->first('option_type') }}</strong>
</span>
@endif
</div>

<div class="form-group">
{!! Form::label('Option Status:') !!}
{!! Form::select('status',[null=>'Select Status','1' => 'Enable', '0' => 'Disable'],null,['class'=>'form-control']) !!}
@if ($errors->has('status'))
<span class="help-block">
<strong>{{ $errors->first('status') }}</strong>
</span
 @endif
 </div>
<div class="form-group">
{!! Form::submit("Save & Update",['class'=>'btn btn-success','ng-disabled'=>'optionform.$invalid']) !!}
 </div>
{!! Form::close() !!}
</div>
</div>
</div>
</div>
@endsection
