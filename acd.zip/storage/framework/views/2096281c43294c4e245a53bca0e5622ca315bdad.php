<?php $__env->startSection('content'); ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
	<script>
	var myApp = angular.module('myApp',[]);
    myApp.config(function($interpolateProvider) {
    $interpolateProvider.startSymbol('//');
    $interpolateProvider.endSymbol('//');
    });
	myApp.controller('dropdownCtrl',function($scope, $http) {
	$scope.results=[{'name':'test'}];
	console.log($scope.results);
	});
      </script>
<div class="container" ng-app="myApp"  ng-controller="dropdownCtrl">
<div class="row">
<div class="panel panel-default">
<div class="panel-heading">Add Information</div>
<div class="panel-body">
<div class="container">
<p><?php echo e($bar); ?></p>	
<!-- THIS IS WHERE WE WILL INJECT OUR CONTENT ============================== -->
</div>
<div ng-repeat="result in results">
<p>//result.name//</p>
</div>
</div>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>