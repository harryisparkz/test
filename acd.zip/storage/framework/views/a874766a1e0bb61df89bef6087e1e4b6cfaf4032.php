<?php $__env->startSection('content'); ?>
<div class="container" ng-app="validationApp" ng-controller="mainController">
<div class="row">
<div class="panel panel-default">
<span><a  class="btn btn-success" href="<?php echo e(url('/state/')); ?>">View state</a></span>
 <div class="panel-heading">Add State</div>
<div class="panel-body">

<?php if(isset($result)): ?>
<?php echo e(Form::model($result, ['route' => ['state.update', $result->id], 'method' => 'PATCH','class'=>'col-md-4','name'=>'stateform','ng-submit'=>'submitForm(stateform.$valid)'])); ?>

<?php else: ?>
<?php echo Form::open(['route'=>'state.store', 'method' => 'POST','class'=>'col-md-4','name'=>'stateform','ng-submit'=>'submitForm(stateform.$valid)']); ?>

<?php endif; ?>
<div class="form-group">
<?php echo Form::label('State Name:'); ?>

<?php echo Form::text('name',null,['class'=>'form-control','autocomplete'=>'off']); ?>

<?php if($errors->has('name')): ?>
<span class="help-block">
<strong><?php echo e($errors->first('name')); ?></strong>
</span>
<?php endif; ?>
 </div>
<div class="form-group">
<?php echo Form::label('State Status:'); ?>

<?php echo Form::select('status',[null=>'Select Status','1' => 'Enable', '0' => 'Disable'],null,['class'=>'form-control']); ?>

<?php if($errors->has('status')): ?>
<span class="help-block">
<strong><?php echo e($errors->first('status')); ?></strong>
</span
 <?php endif; ?>
 </div>
<div class="form-group">
<?php echo Form::submit("Save & Update",['class'=>'btn btn-success','ng-disabled'=>'stateform.$invalid']); ?>

 </div>
<?php echo Form::close(); ?>

</div>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>