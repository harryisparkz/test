<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
               <span><a  class="btn btn-success" href="<?php echo e(url('/categories/create')); ?>">Add Category</a></span>
                <div class="panel-heading">View Department</div>
                <div class="panel-body">
                <table class="table">
<tr>
<th>Category Id </th>
<th>Category Name </th>
<th>Category Url Key</th>
<th>Category Status </th>
<th colspan="2">Apply Action</th>
</tr>
 <tbody>
<?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
<tr>
<td><?php echo e($data->id); ?></td>
<td><?php echo e($data->name); ?></td>
<td><?php echo e($data->url_key); ?></td>
<td><?php if($data->status == 1): ?> Enable <?php else: ?> Disable <?php endif; ?></td>
<td><a href="<?php echo e(route('categories.edit', $data->id)); ?>" class="btn btn-success">Edit</a></td><td><?php echo Form::open([
            'method' => 'DELETE',
            'route' => ['categories.destroy', $data->id]
        ]); ?>

            <?php echo Form::submit('Delete', ['class' => 'btn btn-success']); ?>

        <?php echo Form::close(); ?></td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
</tbody>
</table>
<div class="pagination">
 <?php echo e($result->render()); ?> 
</div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>