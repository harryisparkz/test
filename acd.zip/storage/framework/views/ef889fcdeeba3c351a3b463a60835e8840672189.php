<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
               <span><a  class="btn btn-success" href="<?php echo e(url('/plan/create')); ?>">Add Plan</a></span>
                <div class="panel-heading">View Plan</div>
                <div class="panel-body">
                <table class="table">
<tr>
<th>Plan Id </th>
<th>Category Name </th>
<th>Plan Name </th>
<th>Plan Status </th>
<th colspan="2">Apply Action</th>
</tr>
 <tbody>
<?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
<tr>
<td><?php echo e($data->id); ?></td>
<td><?php echo e($data->categories->name); ?></td>
<td><?php echo e($data->plan_name); ?></td>
<td><?php if($data->status == 1): ?> Enable <?php else: ?> Disable <?php endif; ?></td>
<td><a href="<?php echo e(route('plan.edit', $data->id)); ?>" class="btn btn-success">Edit</a></td><td><?php echo Form::open([
            'method' => 'DELETE',
            'route' => ['plan.destroy',  $data->id]
        ]); ?>

            <?php echo Form::submit('Delete', ['class' => 'btn btn-success']); ?>

        <?php echo Form::close(); ?></td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
</tbody>
</table>
<div class="pagination">

</div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>