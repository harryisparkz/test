<?php $__env->startSection('content'); ?>
	<script>
	var myApp = angular.module('myApp',[]);
    
    /* Config */
    myApp.config(function($interpolateProvider) {
    $interpolateProvider.startSymbol('//');
    $interpolateProvider.endSymbol('//');
    });
	
	/* Controller*/
	myApp.controller('dropdownCtrl',['$http','$filter','$scope','PlanService', function($http,$filter,$scope,PlanService) {
	    $scope.customer ={
	         Category:'',
	         Operator:'',
	         Type:'',
	         Circle:'',
	         Plan:''
	     };
	 $scope.categories = PlanService.getCategory();

	 $scope.getCategoryList = function(){
	    $scope.operators = PlanService.getOperatorList($scope.customer.Category);
	    $scope.types = PlanService.getTypeList($scope.customer.Category);
	    $scope.circles = PlanService.getCircleList($scope.customer.Category);
	    $scope.plans = PlanService.getPlanList($scope.customer.Category);
	  };
	 

	 $scope.getRecord=function()
	 {

	 }
	
	}]);
    
    /* Factory*/
	myApp.factory("PlanService", ['$http','$filter', function($http,$filter){
	var service = {};
	var cagetorylist =<?php echo $cagetorylist?>;
	var operatorlist =<?php echo $operatorlist?>;
	var typelist=<?php echo $typelist?>;
	var circlelist=<?php echo $circlelist?>;  
	var planlist=<?php echo $planlist?>;  
	
	service.getCategory = function(result){    
    return cagetorylist;
    };

    service.getOperatorList = function(category_id){
    var operators = ($filter('filter')(operatorlist, {category_id: category_id}));
    return operators;
    };

    service.getTypeList = function(category_id){
    var types = ($filter('filter')(typelist, {category_id: category_id}));
    return types;
    };

    service.getCircleList = function(category_id){
    var circles = ($filter('filter')(circlelist, {category_id: category_id}));
    return circles;
    };

    service.getPlanList = function(category_id){
    var plans = ($filter('filter')(planlist, {category_id: category_id}));
    return plans;
    };

	return service;
  	}]);
      </script>
<div class="container" ng-app="myApp"  ng-controller="dropdownCtrl">
<div class="row">
<div class="col-md-4">
<div class="panel panel-default">
<div class="panel-heading">Add Information</div>
<div class="panel-body">
	


	 <div class="form-group">
	      <label for="country" class="col-sm-2 control-label">Category</label>
	              
	        <select ng-model="customer.Category" 
	                ng-options="obj.id as obj.name for obj in categories"
	                ng-change="getCategoryList()"
	                class="form-control" 
	                ng-required="true"
	                id="country">
	          <option value="">-- Choose Category --</option>
	        </select>      
	    </div>

      <div class="form-group">
      <label for="state" class="col-sm-2 control-label">Operator</label>
        <select ng-model="customer.Operator" 
                ng-options="x.id as x.operator_name for x in operators"
                class="form-control"
                ng-disabled="!operators || operators.length==0"
                //ng-change = "getTypeList()"
                ng-required="true"
                id="state">
          <option value="">-- Choose Operator--</option>
        </select>      
    </div>

      <div class="form-group">
      <label for="state" class="col-sm-2 control-label">Type</label>
        <select ng-model="customer.Type" 
                ng-options="x.id as x.type_name for x in types"
                //ng-change = "getCircleList()"
                class="form-control"
                ng-disabled="!types || types.length==0"
                ng-required="true"
                id="state">
          <option value="">-- Choose Type--</option>
        </select>      
    </div>
     
      <div class="form-group">
      <label for="state" class="col-sm-2 control-label">Circle</label>
        <select ng-model="customer.Circle" 
                ng-options="x.id as x.states.name for x in circles"
                //ng-change = "getPlanList()"
                class="form-control"
                ng-disabled="!circles || circles.length==0"
                ng-required="true"
                id="state">
          <option value="">-- Choose Circle--</option>
        </select>      
    </div>

    <div class="form-group">
      <label for="state" class="col-sm-2 control-label">Plan</label>
        <select ng-model="customer.Plan" 
                ng-options="x.id as x.plan_name for x in plans"
                class="form-control"
                ng-disabled="!plans || plans.length==0"
                ng-required="true"
                id="state">
          <option value="">-- Choose Plan--</option>
        </select>      
    </div>
   
   <div class="form-group">
      <label for="usr">Talk Time:</label>
      <input type="text" class="form-control" ng-model='customer.Talktime' id="usr">
   
   </div>
   <div class="form-group">
      <label for="usr">Validity:</label>
      <input type="text" class="form-control" ng-model='customer.Validity' id="usr">
   
   </div>
   <div class="form-group">
      <label for="usr">Data Benefits:</label>
      <textarea class="form-control" rows="5" id="comment" ng-model='customer.Benefits'></textarea>
   
   </div>
   <div class="form-group">
      <label for="usr">Price:</label>
      <input type="text" class="form-control" ng-model='customer.Price' id="usr">
   
   </div>
    
  <button type="button" class="btn btn-success">Save Information</button>
   
</div>
</div>
</div>
<div class="col-md-8">
 <table class="table">
  <tr> 
   <th>Category</th>
   <th>Operator</th>
   <th>Type</th>
   <th>Circle</th>
   <th>Plan</th>
   <th>Talk Time</th>
   <th>Validity</th>
   <th>Data Benefits</th>
   <th>Price</th>
   <th colspan="2">Action</th>
   </tr>
 </table>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>