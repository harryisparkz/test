<?php $__env->startSection('content'); ?>
<div class="container" ng-app="validationApp" ng-controller="mainController">
<div class="row">
<div class="panel panel-default">
<span><a  class="btn btn-success" href="<?php echo e(url('/circle/')); ?>">View Circle</a></span>
<div class="panel-heading">Add Circle</div>
<div class="panel-body">
<?php if(session('circlemsg')): ?>
    <div class="alert alert-success">
        <?php echo e(session('circlemsg')); ?>

    </div>
<?php endif; ?>
<?php if(isset($result)): ?>
<?php echo e(Form::model($result, ['route' => ['circle.update', $result->id], 'method' => 'PATCH','class'=>'col-md-4','name'=>'circleform','ng-submit'=>'submitForm(circleform.$valid)'])); ?>

<?php else: ?>
<?php echo Form::open(['route'=>'circle.store', 'method' => 'POST','class'=>'col-md-4','name'=>'circleform','ng-submit'=>'submitForm(circleform.$valid)']); ?>

<?php endif; ?>
<div class="form-group">
<?php echo Form::label('Select Category'); ?>

<?php echo Form::select('category_id',$categories,null,['class'=>'form-control','autocomplete'=>'off']); ?>

<?php if($errors->has('category_id')): ?>
<span class="help-block">
<strong><?php echo e($errors->first('category_id')); ?></strong>
</span>
<?php endif; ?>
</div>
<div class="form-group">
<?php echo Form::label('Select State'); ?>

<?php echo Form::select('state_id',$states,null,['class'=>'form-control','autocomplete'=>'off']); ?>

<?php if($errors->has('state_id')): ?>
<span class="help-block">
<strong><?php echo e($errors->first('state_id')); ?></strong>
</span>
<?php endif; ?>
</div>
<div class="form-group">
<?php echo Form::label('Circle Code:'); ?>

<?php echo Form::text('circle_code',null,['class'=>'form-control','autocomplete'=>'off']); ?>

<?php if($errors->has('circle_code')): ?>
<span class="help-block">
<strong><?php echo e($errors->first('circle_code')); ?></strong>
</span>
<?php endif; ?>
</div>
<div class="form-group">
<?php echo Form::label('Circle Status:'); ?>

<?php echo Form::select('status',[null=>'Select Status','1' => 'Enable', '0' => 'Disable'],null,['class'=>'form-control']); ?>

<?php if($errors->has('status')): ?>
<span class="help-block">
<strong><?php echo e($errors->first('status')); ?></strong>
</span
 <?php endif; ?>
 </div>
<div class="form-group">
<?php echo Form::submit("Save & Update",['class'=>'btn btn-success','ng-disabled'=>'operatorform.$invalid']); ?>

 </div>
<?php echo Form::close(); ?>

</div>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>